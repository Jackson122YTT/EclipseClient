#!/usr/bin/env python3
"""
Eclipse Client 2.0 - Project Generator
Minecraft 1.8.9 | Forge Mod + Injector

Usage:
    python generate_eclipse.py [--output DIR] [--zip] [--clean]
"""

import os
import sys
import argparse
import zipfile
import shutil
from pathlib import Path
from datetime import datetime

# ═══════════════════════════════════════════════════════════════
# CONFIG
# ═══════════════════════════════════════════════════════════════

MOD_ID = "eclipse"
MOD_NAME = "Eclipse"
VERSION = "2.0.0"
MC_VERSION = "1.8.9"
MAPPINGS = "stable_22"
FORGE_VERSION = "11.15.1.2318-1.8.9"

# Colors for terminal
R = "\033[91m"
G = "\033[92m"
Y = "\033[93m"
C = "\033[96m"
W = "\033[97m"
B = "\033[1m"
D = "\033[2m"
X = "\033[0m"

def ok(m): print(f"  {G}+{X} {m}")
def err(m): print(f"  {R}!{X} {m}")
def info(m): print(f"  {C}>{X} {m}")

def banner():
    print(f"""
{R}{B}  EEEEEEEEEEEEEEEEEEEEEE       CCCCCCCCCCCCC
  E::::::::::::::::::::E     CCC::::::::::::C
  E::::::::::::::::::::E   CC:::::::::::::::C
  EE::::::EEEEEEEEE::::E  C:::::CCCCCCCC::::C
  E:::::E       EEEEEE   C:::::C       CCCCCC
  E:::::E                 C:::::C
  E::::::EEEEEEEEEE       C:::::C
  E:::::::::::::::E        C:::::C
  E:::::::::::::::E        C:::::C
  E::::::EEEEEEEEEE        C:::::C
  E:::::E                 C:::::C
  E:::::E       EEEEEE   C:::::C       CCCCCC
  EE::::::EEEEEEEEEE::::E  C:::::CCCCCCCC::::C
  E::::::::::::::::::::E   CC:::::::::::::::C
  E::::::::::::::::::::E     CCC::::::::::::C
  EEEEEEEEEEEEEEEEEEEEEE       CCCCCCCCCCCCC{X}
{C}           Generator v{VERSION} | MC {MC_VERSION}{X}
""")

# ═══════════════════════════════════════════════════════════════
# FILE CONTENTS - Using raw strings to avoid escape issues
# ═══════════════════════════════════════════════════════════════

BUILD_GRADLE = r"""buildscript {
    repositories {
        mavenCentral()
        maven { url = "https://maven.minecraftforge.net/" }
    }
    dependencies {
        classpath 'net.minecraftforge.gradle:ForgeGradle:2.3-SNAPSHOT'
    }
}

apply plugin: 'net.minecraftforge.gradle.forge'

version = "2.0.0"
group = "me.eclipse"
archivesBaseName = "Eclipse"

sourceCompatibility = targetCompatibility = '1.8'

minecraft {
    version = "1.8.9-11.15.1.2318-1.8.9"
    runDir = "run"
    mappings = "stable_22"
    makeObfSourceJar = false
}

repositories {
    mavenCentral()
}

jar {
    manifest {
        attributes 'FMLCorePlugin': 'me.eclipse.core.EclipseMixinPlugin'
        attributes 'FMLCorePluginContainsFMLMod': 'true'
    }
}
"""

SETTINGS_GRADLE = "rootProject.name = 'Eclipse'\n"

GRADLE_PROPS = """org.gradle.jvmargs=-Xmx2048m
minecraft_version=1.8.9
mappings_version=stable_22
forge_version=11.15.1.2318-1.8.9
mod_version=2.0.0
"""

GITIGNORE = """.gradle/
build/
out/
run/
logs/
*.class
*.jar
*.log
*.iml
.idea/
.DS_Store
"""

README = """# Eclipse Client v2.0.0

## Minecraft 1.8.9 Hacked Client
### Forge Mod + Injector Hybrid

## Building
1. Run `gradle wrapper` to generate wrapper files
2. Run `gradlew setupDecompWorkspace`
3. Run `gradlew build`
4. Find JAR in `build/libs/`

## Commands
- `.toggle <module>` - Toggle module
- `.help` - Show commands
- `.watchdog profile <name>` - Set WD profile

## Injector
See `eclipse-injector/` for C++ injector source.
"""

MCMOD_INFO = """[
  {
    "modid": "eclipse",
    "name": "Eclipse",
    "description": "Advanced Minecraft 1.8.9 Client",
    "version": "${version}",
    "mcversion": "${mcversion}",
    "authorList": ["Eclipse Team"],
    "dependencies": []
  }
]
"""

MIXIN_JSON = """{
  "required": true,
  "package": "me.eclipse.mixin",
  "refmap": "mixins.eclipse.refmap.json",
  "plugin": "me.eclipse.core.EclipseMixinPlugin",
  "target": "@env(DEFAULT)",
  "minVersion": "0.7",
  "compatibilityLevel": "JAVA_8",
  "mixins": [
    "MixinMinecraft",
    "MixinEntity",
    "MixinEntityPlayerSP",
    "MixinPlayerControllerMP",
    "MixinNetHandlerPlayClient",
    "MixinNetworkManager",
    "MixinAbstractClientPlayer"
  ],
  "client": [
    "MixinWorldRenderer",
    "MixinRenderManager",
    "MixinRendererLivingEntity",
    "MixinGuiIngame",
    "MixinGuiScreen"
  ]
}
"""

# ═══════════════════════════════════════════════════════════════
# JAVA CORE FILES
# ═══════════════════════════════════════════════════════════════

ECLIPSE_MAIN = """package me.eclipse;

import me.eclipse.core.*;
import me.eclipse.gui.font.FontRenderer;
import me.eclipse.utils.Logger;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import org.lwjgl.opengl.Display;

@Mod(modid = Eclipse.MOD_ID, name = Eclipse.MOD_NAME, version = Eclipse.VERSION)
public class Eclipse {
    public static final String MOD_ID = "eclipse";
    public static final String MOD_NAME = "Eclipse";
    public static final String VERSION = "2.0.0";
    
    public static Eclipse instance;
    public ModuleManager moduleManager;
    public CommandManager commandManager;
    public ConfigManager configManager;
    public FriendManager friendManager;
    public WaypointManager waypointManager;
    public RotationManager rotationManager;
    public EventBus eventBus;
    public FontRenderer fontRenderer;
    public FontRenderer fontRendererBold;
    public FontRenderer monoFont;
    public static String commandPrefix = ".";
    
    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        instance = this;
        long start = System.currentTimeMillis();
        
        eventBus = new EventBus();
        moduleManager = new ModuleManager();
        commandManager = new CommandManager();
        configManager = new ConfigManager();
        friendManager = new FriendManager();
        waypointManager = new WaypointManager();
        rotationManager = new RotationManager();
        
        try {
            fontRenderer = new FontRenderer(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 18), true, true);
            fontRendererBold = new FontRenderer(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 18), true, true);
            monoFont = new FontRenderer(new java.awt.Font("Consolas", java.awt.Font.PLAIN, 14), true, true);
        } catch (Exception e) {
            Logger.log("Font load failed: " + e.getMessage());
        }
        
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(moduleManager);
        configManager.loadConfigs();
        
        long ms = System.currentTimeMillis() - start;
        Logger.log("Eclipse v" + VERSION + " loaded in " + ms + "ms");
        Logger.log("Modules: " + moduleManager.getModules().size());
        Display.setTitle("Eclipse 2.0 | 1.8.9");
    }
}
"""

EVENT_BUS = """package me.eclipse.core;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventBus {
    private final Map<Class<?>, CopyOnWriteArrayList<EventListener>> listeners = new ConcurrentHashMap<>();
    
    public void register(Object obj) {
        for (Method m : obj.getClass().getDeclaredMethods()) {
            if (m.isAnnotationPresent(EventHandler.class) && m.getParameterCount() == 1) {
                m.setAccessible(true);
                Class<?> cls = m.getParameterTypes()[0];
                listeners.computeIfAbsent(cls, k -> new CopyOnWriteArrayList<>())
                    .add(new EventListener(obj, m, m.getAnnotation(EventHandler.class).priority()));
                listeners.get(cls).sort(Comparator.comparingInt(e -> e.priority));
            }
        }
    }
    
    public void unregister(Object obj) {
        listeners.values().forEach(l -> l.removeIf(e -> e.obj == obj));
    }
    
    @SuppressWarnings("unchecked")
    public <T> T post(T event) {
        CopyOnWriteArrayList<EventListener> list = listeners.get(event.getClass());
        if (list != null) {
            for (EventListener el : list) {
                try { el.method.invoke(el.obj, event); }
                catch (Exception e) { e.printStackTrace(); }
                if (event instanceof Cancellable && ((Cancellable) event).isCancelled()) break;
            }
        }
        return event;
    }
    
    private static class EventListener {
        final Object obj; final Method method; final int priority;
        EventListener(Object o, Method m, int p) { obj = o; method = m; priority = p; }
    }
}
"""

EVENT_HANDLER = """package me.eclipse.core;

import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface EventHandler { int priority() default 0; }
"""

CANCELLABLE = """package me.eclipse.core;
public interface Cancellable {
    boolean isCancelled();
    void setCancelled(boolean cancelled);
}
"""

MODULE_BASE = """package me.eclipse.module;

import me.eclipse.Eclipse;
import me.eclipse.core.EventBus;
import me.eclipse.module.setting.Setting;
import net.minecraft.client.Minecraft;
import java.util.ArrayList;
import java.util.List;

public class Module {
    protected final Minecraft mc = Minecraft.getMinecraft();
    protected static final EventBus eventBus = Eclipse.instance.eventBus;
    private final String name, description;
    private final Category category;
    private final int keyBind;
    private boolean enabled, hidden;
    private final List<Setting> settings = new ArrayList<>();
    private float slide, targetSlide;
    
    public Module(String name, String desc, Category cat, int key) {
        this.name = name; this.description = desc; this.category = cat; this.keyBind = key;
    }
    
    public void onEnable() {}
    public void onDisable() {}
    public void onToggle() {}
    
    public void enable() {
        enabled = true; targetSlide = 1f; eventBus.register(this); onEnable(); onToggle();
    }
    public void disable() {
        enabled = false; targetSlide = 0f; eventBus.unregister(this); onDisable(); onToggle();
    }
    public void toggle() { if (enabled) disable(); else enable(); }
    public void addSetting(Setting s) { settings.add(s); }
    public Setting getSetting(String n) {
        return settings.stream().filter(s -> s.getName().equalsIgnoreCase(n)).findFirst().orElse(null);
    }
    public float getSlide(float dt) { slide += (targetSlide - slide) * Math.min(1f, dt * 8f); return slide; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public int getKeyBind() { return keyBind; }
    public boolean isEnabled() { return enabled; }
    public boolean isHidden() { return hidden; }
    public List<Setting> getSettings() { return settings; }
    public void setHidden(boolean h) { hidden = h; }
    public void setEnabled(boolean e) { if (e && !enabled) enable(); else if (!e && enabled) disable(); }
}
"""

MODULE_INFO = """package me.eclipse.module;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface ModuleInfo {
    String name(); String description(); me.eclipse.module.enums.Category category(); int keyBind();
}
"""

CATEGORY = """package me.eclipse.module.enums;

public enum Category {
    COMBAT("Combat", 0xFFE74C3C),
    MOVEMENT("Movement", 0xFF3498DB),
    PLAYER("Player", 0xFF2ECC71),
    RENDER("Render", 0xFF9B59B6),
    WATCHDOG("Watchdog", 0xFFF39C12),
    MISC("Misc", 0xFF1ABC9C);
    
    private final String name; private final int color;
    Category(String n, int c) { name = n; color = c; }
    public String getName() { return name; }
    public int getColor() { return color; }
    public String getIcon() {
        switch(this) {
            case COMBAT: return "S"; case MOVEMENT: return "D"; case PLAYER: return "E";
            case RENDER: return "G"; case WATCHDOG: return "W"; case MISC: return "F";
            default: return "?";
        }
    }
}
"""

MODULE_MANAGER = """package me.eclipse.core;

import me.eclipse.module.Module;
import me.eclipse.module.combat.*;
import me.eclipse.module.movement.*;
import me.eclipse.module.player.*;
import me.eclipse.module.render.*;
import me.eclipse.module.watchdog.*;
import me.eclipse.module.misc.*;
import me.eclipse.module.enums.Category;
import java.util.*;
import java.util.stream.Collectors;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    
    public ModuleManager() {
        register(new KillAura(), new Velocity(), new Criticals(), new AutoClicker(),
                 new Reach(), new CPSLimit(), new BowAimbot(), new AutoPot(),
                 new AutoSoup(), new AutoHeal(), new AntiBot(), new Backtrack(), new TargetStrafe());
        register(new Speed(), new Fly(), new LongJump(), new NoSlow(), new Strafe(),
                 new Spider(), new Step(), new HighJump(), new LiquidWalk(), new Jesus(),
                 new SafeWalk(), new AirJump(), new Timer());
        register(new Scaffold(), new Tower(), new AutoArmor(), new ChestStealer(),
                 new InvManager(), new AutoTool(), new AutoFish(), new AutoGG(),
                 new AutoPlay(), new AntiVoid(), new Blink(), new Phase(), new Disabler(), new Freecam());
        register(new ClickGUI(), new HUD(), new ArrayListMod(), new Keystrokes(),
                 new CPSCounter(), new TargetHUD(), new NameTags(), new Tracers(),
                 new Radar(), new BlockOverlay(), new Breadcrumbs(), new JumpCircle(),
                 new ChinaHat(), new StorageESP(), new ItemESP(), new ProjectileESP(),
                 new Chams(), new ESP(), new Trajectories(), new Fullbright(),
                 new Xray(), new ItemPhysics(), new Animations(), new NoRender());
        register(new WDSpeed(), new WDScaffold(), new WDKillAura(), new WDMovement(),
                 new WDNoSlow(), new WDVelocity(), new WDTimer(), new WDDisabler(),
                 new WDMacro(), new WDProfile(), new WDFingerprint());
        register(new Spammer(), new MidClick(), new AutoRespawn(), new SkinFlicker(),
                 new NameProtect(), new LootFilter(), new PearlPhaser(), new AntiHunger(),
                 new PortalMenu(), new NoRotateSet(), new PacketLimiter(), new SessionInfo());
    }
    
    private void register(Module... ms) { modules.addAll(Arrays.asList(ms)); }
    public Module getModule(String n) { return modules.stream().filter(m -> m.getName().equalsIgnoreCase(n)).findFirst().orElse(null); }
    public <T extends Module> T getModule(Class<T> c) { return modules.stream().filter(m -> m.getClass() == c).map(m -> (T)m).findFirst().orElse(null); }
    public List<Module> getModulesInCategory(Category c) { return modules.stream().filter(m -> m.getCategory() == c).collect(Collectors.toList()); }
    public List<Module> getEnabledModules() { return modules.stream().filter(Module::isEnabled).collect(Collectors.toList()); }
    public List<Module> getModules() { return modules; }
}
"""

ROTATION_MANAGER = """package me.eclipse.core;

import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.client.Minecraft;

public class RotationManager {
    private float serverYaw, serverPitch;
    private static final Minecraft mc = Minecraft.getMinecraft();
    
    public RotationPair getRotations(Entity target, float height, float yStep, float pStep) {
        double dx = target.posX - mc.thePlayer.posX;
        double dy = (target.posY + target.getEyeHeight() * height) - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = target.posZ - mc.thePlayer.posZ;
        float yaw = MathHelper.wrapAngleTo180_float((float)Math.toDegrees(Math.atan2(dz, dx)) - 90f);
        float pitch = MathHelper.clamp_float((float)-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx*dx + dz*dz))), -90f, 90f);
        return new RotationPair(lerp(serverYaw, yaw, yStep), lerp(serverPitch, pitch, pStep));
    }
    
    private float lerp(float from, float to, float speed) {
        float d = MathHelper.wrapAngleTo180_float(to - from);
        return Math.abs(d) < speed ? to : from + (d > 0 ? speed : -speed);
    }
    
    public void updateServerRotations(float y, float p) { serverYaw = y; serverPitch = p; }
    public float getServerYaw() { return serverYaw; }
    public float getServerPitch() { return serverPitch; }
    
    public static class RotationPair { public final float yaw, pitch; public RotationPair(float y, float p) { yaw = y; pitch = p; } }
}
"""

MIXIN_PLUGIN = """package me.eclipse.core;

import org.spongepowered.asm.launch.MixinBootstrap;
import org.spongepowered.asm.mixin.MixinEnvironment;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
import java.util.Map;

public class EclipseMixinPlugin implements IFMLLoadingPlugin {
    public EclipseMixinPlugin() {
        MixinBootstrap.init();
        MixinEnvironment.getDefaultEnvironment().setObfuscationContext("searge");
    }
    public String[] getASMTransformerClass() { return new String[0]; }
    public String getModContainerClass() { return null; }
    public String getSetupClass() { return null; }
    public void injectData(Map<String, Object> data) {}
    public String getAccessTransformerClass() { return null; }
}
"""

# ═══════════════════════════════════════════════════════════════
# SETTINGS
# ═══════════════════════════════════════════════════════════════

SETTING_BASE = """package me.eclipse.module.setting;
public abstract class Setting {
    private final String name;
    public Setting(String n) { name = n; }
    public String getName() { return name; }
    public abstract double getMin();
    public abstract double getMax();
    public abstract double getIncrement();
}
"""

SETTING_BOOL = """package me.eclipse.module.setting;
public class SettingBoolean extends Setting {
    private boolean value;
    public SettingBoolean(String n, boolean v) { super(n); value = v; }
    public boolean getValue() { return value; }
    public void setValue(boolean v) { value = v; }
    public double getMin() { return 0; }
    public double getMax() { return 1; }
    public double getIncrement() { return 1; }
}
"""

SETTING_DOUBLE = """package me.eclipse.module.setting;
public class SettingDouble extends Setting {
    private double value, min, max, inc;
    public SettingDouble(String n, double v, double mn, double mx, double i) { super(n); value=v; min=mn; max=mx; inc=i; }
    public double getValue() { return value; }
    public void setValue(double v) { value = v; }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getIncrement() { return inc; }
}
"""

SETTING_INT = """package me.eclipse.module.setting;
public class SettingInteger extends Setting {
    private int value, min, max, inc;
    public SettingInteger(String n, int v, int mn, int mx, int i) { super(n); value=v; min=mn; max=mx; inc=i; }
    public int getValue() { return value; }
    public void setValue(int v) { value = v; }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getIncrement() { return inc; }
}
"""

SETTING_MODE = """package me.eclipse.module.setting;
public class SettingMode extends Setting {
    private final String[] modes;
    private int idx;
    public SettingMode(String n, String[] m, String def) {
        super(n); modes = m;
        for (int i = 0; i < m.length; i++) if (m[i].equals(def)) { idx = i; return; }
    }
    public String getValue() { return modes[idx]; }
    public void setValue(String v) { for (int i = 0; i < modes.length; i++) if (modes[i].equals(v)) { idx = i; return; } }
    public String[] getModes() { return modes; }
    public double getMin() { return 0; }
    public double getMax() { return modes.length - 1; }
    public double getIncrement() { return 1; }
}
"""

SETTING_COLOR = """package me.eclipse.module.setting;
import java.awt.Color;
public class SettingColor extends Setting {
    private Color color;
    public SettingColor(String n, Color c) { super(n); color = c; }
    public SettingColor(String n, int r, int g, int b, int a) { super(n); color = new Color(r, g, b, a); }
    public Color getColor() { return color; }
    public void setColor(Color c) { color = c; }
    public double getMin() { return 0; }
    public double getMax() { return 255; }
    public double getIncrement() { return 1; }
}
"""

SETTING_FLOAT = """package me.eclipse.module.setting;
public class SettingFloat extends Setting {
    private float value, min, max, inc;
    public SettingFloat(String n, float v, float mn, float mx, float i) { super(n); value=v; min=mn; max=mx; inc=i; }
    public float getValue() { return value; }
    public void setValue(float v) { value = v; }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getIncrement() { return inc; }
}
"""

# ═══════════════════════════════════════════════════════════════
# NETWORK
# ═══════════════════════════════════════════════════════════════

PACKET_HANDLER = """package me.eclipse.network;

import me.eclipse.core.Cancellable;
import net.minecraft.network.Packet;

public class PacketEvent {
    public static class Send implements Cancellable {
        private Packet<?> packet; private boolean cancelled;
        public Send(Packet<?> p) { packet = p; }
        public Packet<?> getPacket() { return packet; }
        public boolean isCancelled() { return cancelled; }
        public void setCancelled(boolean c) { cancelled = c; }
    }
    public static class Receive implements Cancellable {
        private Packet<?> packet; private boolean cancelled;
        public Receive(Packet<?> p) { packet = p; }
        public Packet<?> getPacket() { return packet; }
        public boolean isCancelled() { return cancelled; }
        public void setCancelled(boolean c) { cancelled = c; }
    }
}
"""

# ═══════════════════════════════════════════════════════════════
# UTILS
# ═══════════════════════════════════════════════════════════════

LOGGER = """package me.eclipse.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

public class Logger {
    private static final String P = EnumChatFormatting.RED + "[" + EnumChatFormatting.WHITE + "Eclipse" + EnumChatFormatting.RED + "]" + EnumChatFormatting.GRAY + ";
    public static void log(String m) {
        if (Minecraft.getMinecraft().thePlayer != null)
            Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText(P + m));
        System.out.println("[Eclipse] " + m);
    }
}
"""

RENDER_UTILS = """package me.eclipse.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.BlockPos;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import java.awt.*;

public class RenderUtils {
    private static final Minecraft mc = Minecraft.getMinecraft();
    
    public static void drawRoundedRect(float x, float y, float x2, float y2, float r, int color) {
        GlStateManager.enableBlend(); GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GL14.GL_FUNC_ADD, GL14.GL_FUNC_ADD, GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        float a = (color >> 24 & 255) / 255f, red = (color >> 16 & 255) / 255f, g = (color >> 8 & 255) / 255f, b = (color & 255) / 255f;
        Tessellator t = Tessellator.getInstance(); WorldRenderer w = t.getWorldRenderer();
        w.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        addRect(w, x+r, y, x2-r, y2, red, g, b, a); addRect(w, x, y+r, x2, y2-r, red, g, b, a);
        for (int i = 0; i < 4; i++) addCorner(w, i, x, y, x2, y2, r, red, g, b, a);
        t.draw(); GlStateManager.enableTexture2D(); GlStateManager.disableBlend();
    }
    private static void addRect(WorldRenderer w, float x, float y, float x2, float y2, float r, float g, float b, float a) {
        w.pos(x,y2,0).color(r,g,b,a).endVertex(); w.pos(x2,y2,0).color(r,g,b,a).endVertex();
        w.pos(x2,y,0).color(r,g,b,a).endVertex(); w.pos(x,y,0).color(r,g,b,a).endVertex();
    }
    private static void addCorner(WorldRenderer w, int corner, float x, float y, float x2, float y2, float rad, float r, float g, float b, float a) {
        float cx = corner < 2 ? x2-rad : x+rad, cy = corner % 2 == 0 ? y+rad : y2-rad;
        float start = corner * (float)Math.PI/2;
        for (int i = 0; i < 8; i++) {
            float a1 = start + (i/8f)*(float)Math.PI/2, a2 = start + ((i+1)/8f)*(float)Math.PI/2;
            w.pos(cx,cy,0).color(r,g,b,a).endVertex();
            w.pos(cx+(float)Math.cos(a1)*rad, cy+(float)Math.sin(a1)*rad, 0).color(r,g,b,a).endVertex();
            w.pos(cx+(float)Math.cos(a2)*rad, cy+(float)Math.sin(a2)*rad, 0).color(r,g,b,a).endVertex();
        }
    }
    public static void drawRect(float x, float y, float x2, float y2, int color) {
        GlStateManager.enableBlend(); GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GL14.GL_FUNC_ADD, GL14.GL_FUNC_ADD, GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        float a=(color>>24&255)/255f, r=(color>>16&255)/255f, g=(color>>8&255)/255f, b=(color&255)/255f;
        Tessellator t=Tessellator.getInstance(); WorldRenderer w=t.getWorldRenderer();
        w.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        w.pos(x,y2,0).color(r,g,b,a).endVertex(); w.pos(x2,y2,0).color(r,g,b,a).endVertex();
        w.pos(x2,y,0).color(r,g,b,a).endVertex(); w.pos(x,y,0).color(r,g,b,a).endVertex();
        t.draw(); GlStateManager.enableTexture2D(); GlStateManager.disableBlend();
    }
    public static void drawCircle(float cx, float cy, float r, int color) {
        GlStateManager.enableBlend(); GlStateManager.disableTexture2D();
        float a=(color>>24&255)/255f, red=(color>>16&255)/255f, g=(color>>8&255)/255f, b=(color&255)/255f;
        Tessellator t=Tessellator.getInstance(); WorldRenderer w=t.getWorldRenderer();
        w.begin(GL11.GL_TRIANGLE_FAN, DefaultVertexFormats.POSITION_COLOR);
        w.pos(cx,cy,0).color(red,g,b,a).endVertex();
        for(int i=0;i<=32;i++){float ang=(i/32f)*(float)Math.PI*2;w.pos(cx+(float)Math.cos(ang)*r,cy+(float)Math.sin(ang)*r,0).color(red,g,b,a).endVertex();}
        t.draw(); GlStateManager.enableTexture2D(); GlStateManager.disableBlend();
    }
    public static void drawLine(float x1,float y1,float x2,float y2,float w,int c){
        GlStateManager.enableBlend();GlStateManager.disableTexture2D();GL11.glLineWidth(w);
        float a=(c>>24&255)/255f,r=(c>>16&255)/255f,g=(c>>8&255)/255f,b=(c&255)/255f;
        GL11.glBegin(GL11.GL_LINES);GL11.glColor4f(r,g,b,a);GL11.glVertex2f(x1,y1);GL11.glVertex2f(x2,y2);GL11.glEnd();
        GlStateManager.enableTexture2D();GlStateManager.disableBlend();
    }
    public static void drawBlockOutline(BlockPos pos, int color, float lw) {
        GlStateManager.enableBlend(); GlStateManager.disableDepth(); GlStateManager.disableTexture2D(); GL11.glLineWidth(lw);
        float a=(color>>24&255)/255f,r=(color>>16&255)/255f,g=(color>>8&255)/255f,b=(color&255)/255f;
        double x=pos.getX()-mc.getRenderManager().viewerPosX, y=pos.getY()-mc.getRenderManager().viewerPosY, z=pos.getZ()-mc.getRenderManager().viewerPosZ;
        GL11.glBegin(GL11.GL_LINES);GL11.glColor4f(r,g,b,a);
        GL11.glVertex3d(x,y,z);GL11.glVertex3d(x+1,y,z); GL11.glVertex3d(x+1,y,z);GL11.glVertex3d(x+1,y,z+1);
        GL11.glVertex3d(x+1,y,z+1);GL11.glVertex3d(x,y,z+1); GL11.glVertex3d(x,y,z+1);GL11.glVertex3d(x,y,z);
        GL11.glVertex3d(x,y+1,z);GL11.glVertex3d(x+1,y+1,z); GL11.glVertex3d(x+1,y+1,z);GL11.glVertex3d(x+1,y+1,z+1);
        GL11.glVertex3d(x+1,y+1,z+1);GL11.glVertex3d(x,y+1,z+1); GL11.glVertex3d(x,y+1,z+1);GL11.glVertex3d(x,y+1,z);
        GL11.glVertex3d(x,y,z);GL11.glVertex3d(x,y+1,z); GL11.glVertex3d(x+1,y,z);GL11.glVertex3d(x+1,y+1,z);
        GL11.glVertex3d(x+1,y,z+1);GL11.glVertex3d(x+1,y+1,z+1); GL11.glVertex3d(x,y,z+1);GL11.glVertex3d(x,y+1,z+1);
        GL11.glEnd(); GlStateManager.enableDepth(); GlStateManager.enableTexture2D(); GlStateManager.disableBlend();
    }
    public static void startScissor(float x, float y, float w, float h) {
        ScaledResolution sr = new ScaledResolution(mc); int s = sr.getScaleFactor();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor((int)(x*s),(int)((sr.getScaledHeight()-y-h)*s),(int)(w*s),(int)(h*s));
    }
    public static void endScissor() { GL11.glDisable(GL11.GL_SCISSOR_TEST); }
}
"""

RANDOM_UTILS = """package me.eclipse.utils;
import java.util.Random;
public class RandomUtils {
    private static final Random r = new Random();
    public static int nextInt(int min, int max) { return min + r.nextInt(max - min + 1); }
    public static float nextFloat(float min, float max) { return min + r.nextFloat() * (max - min); }
    public static double nextDouble(double min, double max) { return min + r.nextDouble() * (max - min); }
    public static double nextGaussian(double sd) { return r.nextGaussian() * sd; }
    public static boolean chance(double pct) { return r.nextDouble() * 100 < pct; }
}
"""

ANIM_UTILS = """package me.eclipse.utils;
public class AnimationUtils {
    public static float easeOutCubic(float t) { return 1f - (float)Math.pow(1-t, 3); }
    public static float easeInCubic(float t) { return t*t*t; }
    public static float easeOutBack(float t) { float c=1.70158f; return 1f+(c+1f)*(float)Math.pow(t-1f,3)+c*(float)Math.pow(t-1f,2); }
    public static float easeOutBounce(float t) {
        float n=7.5625f,d=2.75f;
        if(t<1f/d)return n*t*t;else if(t<2f/d){t-=1.5f/d;return n*t*t+0.75f;}
        else if(t<2.5f/d){t-=2.25f/d;return n*t*t+0.9375f;}else{t-=2.625f/d;return n*t*t+0.984375f;}
    }
    public static float lerp(float from, float to, float speed) { return from + (to-from) * Math.min(1f, speed); }
}
"""

ENTITY_UTILS = """package me.eclipse.utils;
import net.minecraft.entity.Entity;import net.minecraft.entity.EntityLivingBase;import net.minecraft.entity.monster.EntityMob;import net.minecraft.entity.passive.EntityAnimal;import net.minecraft.entity.player.EntityPlayer;
public class EntityUtils {
    public static boolean isMob(Entity e) { return e instanceof EntityMob; }
    public static boolean isAnimal(Entity e) { return e instanceof EntityAnimal; }
    public static boolean isPlayer(Entity e) { return e instanceof EntityPlayer; }
}
"""

MATH_UTILS = """package me.eclipse.utils;
import net.minecraft.client.Minecraft;
public class MathUtils {
    private static final Minecraft mc = Minecraft.getMinecraft();
    public static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
    public static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
}
"""

BLOCK_UTILS = """package me.eclipse.utils;
import net.minecraft.block.Block;import net.minecraft.client.Minecraft;import net.minecraft.util.BlockPos;
public class BlockUtils {
    private static final Minecraft mc = Minecraft.getMinecraft();
    public static Block getBlock(BlockPos p) { return mc.theWorld.getBlockState(p).getBlock(); }
    public static boolean isFullBlock(BlockPos p) { return getBlock(p).isFullBlock(); }
}
"""

BLUR_UTILS = """package me.eclipse.utils;
import net.minecraft.client.Minecraft;
public class BlurUtils {
    public static void renderBlur(float strength) {
        // Simplified blur overlay
        RenderUtils.drawRect(0, 0, Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight, 0x80000000);
    }
}
"""

FONT_RENDERER = """package me.eclipse.gui.font;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

public class FontRenderer {
    private final Map<Character, Glyph> glyphs = new HashMap<>();
    private float height;
    private final ResourceLocation tex;
    
    private static class Glyph { float u,v,w,h,adv,ox,oy; }
    
    public FontRenderer(Font font, boolean aa, boolean fm) {
        int W=1024,H=1024; BufferedImage img=new BufferedImage(W,H,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g=img.createGraphics();
        if(aa){g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);}
        g.setFont(font);g.setColor(Color.WHITE);
        java.awt.FontMetrics metrics=g.getFontMetrics();
        int x=1,y=1,lh=metrics.getHeight()+2;
        for(int i=32;i<256;i++){char c=(char)i;int cw=metrics.charWidth(c);
            if(x+cw+2>W){x=1;y+=lh;}if(y+lh>H)break;
            g.drawString(String.valueOf(c),x,y+metrics.getAscent());
            Glyph gl=new Glyph();gl.u=x/(float)W;gl.v=y/(float)H;gl.w=cw/(float)W;gl.h=lh/(float)H;gl.adv=cw;gl.ox=0;gl.oy=-metrics.getAscent();
            glyphs.put(c,gl);x+=cw+2;}
        g.dispose();
        tex=Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("eclipse_font",new DynamicTexture(img));
        height=(float)metrics.getHeight()*0.65f;
    }
    
    public float drawString(String text,float x,float y,int color,boolean shadow){
        if(text==null||text.isEmpty())return x;
        GlStateManager.enableBlend();GlStateManager.blendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);GlStateManager.disableDepth();
        Minecraft.getMinecraft().getTextureManager().bindTexture(tex);
        float a=(color>>24&255)/255f,r=(color>>16&255)/255f,g=(color>>8&255)/255f,b=(color&255)/255f;
        if(shadow)drawInternal(text,x+1,y+1,0,0,0,a*0.5f);
        float rx=drawInternal(text,x,y,r,g,b,a);
        GlStateManager.enableDepth();GlStateManager.disableBlend();return rx;
    }
    private float drawInternal(String text,float x,float y,float r,float g,float b,float a){
        GlStateManager.color(r,g,b,a);GL11.glBegin(GL11.GL_QUADS);float cx=x;
        for(int i=0;i<text.length();i++){char c=text.charAt(i);Glyph gl=glyphs.get(c);
            if(gl==null){Glyph sp=glyphs.get(' ');if(sp!=null)cx+=sp.adv;continue;}
            float x1=cx+gl.ox,y1=y+gl.oy,x2=x1+gl.w*1024,y2=y1+gl.h*1024;
            GL11.glTexCoord2f(gl.u,gl.v);GL11.glVertex2f(x1,y1);
            GL11.glTexCoord2f(gl.u+gl.w,gl.v);GL11.glVertex2f(x2,y1);
            GL11.glTexCoord2f(gl.u+gl.w,gl.v+gl.h);GL11.glVertex2f(x2,y2);
            GL11.glTexCoord2f(gl.u,gl.v+gl.h);GL11.glVertex2f(x1,y2);
            cx+=gl.adv;}
        GL11.glEnd();return cx;
    }
    public int getStringWidth(String t){if(t==null)return 0;int w=0;for(int i=0;i<t.length();i++){char c=t.charAt(i);Glyph g=glyphs.get(c);w+=g!=null?g.adv:(glyphs.get(' ')!=null?glyphs.get(' ').adv:0);}return w;}
    public float getHeight(){return height;}
}
"""

# ═══════════════════════════════════════════════════════════════
# MANAGERS
# ═══════════════════════════════════════════════════════════════

CONFIG_MANAGER = """package me.eclipse.core;

import me.eclipse.Eclipse;
import me.eclipse.utils.Logger;
import java.io.File;

public class ConfigManager {
    private final File dir;
    public ConfigManager() { dir = new File(Eclipse.instance.mc.mcDataDir, "eclipse"); if(!dir.exists()) dir.mkdirs(); }
    public void saveConfig(String name) { Logger.log("Config saved: " + name); }
    public void loadConfig(String name) { Logger.log("Config loaded: " + name); }
    public void loadConfigs() {}
}
"""

FRIEND_MANAGER = """package me.eclipse.core;
import java.util.HashSet;
import java.util.Set;
public class FriendManager {
    private final Set<String> friends = new HashSet<>();
    public boolean isFriend(String n) { return friends.contains(n.toLowerCase()); }
    public void addFriend(String n) { friends.add(n.toLowerCase()); }
    public void removeFriend(String n) { friends.remove(n.toLowerCase()); }
    public Set<String> getFriends() { return friends; }
}
"""

WAYPOINT_MANAGER = """package me.eclipse.core;
import java.util.ArrayList;
import java.util.List;
public class WaypointManager {
    public static class Waypoint { public String name; public double x,y,z; public int color; }
    private final List<Waypoint> wps = new ArrayList<>();
    public void addWaypoint(Waypoint w) { wps.add(w); }
    public void removeWaypoint(Waypoint w) { wps.remove(w); }
    public List<Waypoint> getWaypoints() { return wps; }
}
"""

# ═══════════════════════════════════════════════════════════════
# COMMANDS
# ═══════════════════════════════════════════════════════════════

COMMAND_BASE = """package me.eclipse.command;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

public abstract class Command {
    protected final String name, description;
    protected final String[] aliases;
    protected final Minecraft mc = Minecraft.getMinecraft();
    
    public Command(String n, String d, String... a) { name = n; description = d; aliases = a; }
    public abstract void execute(String[] args);
    public boolean matches(String i) {
        if(i.equalsIgnoreCase(name)) return true;
        for(String a : aliases) if(i.equalsIgnoreCase(a)) return true;
        return false;
    }
    public String getName() { return name; }
    protected void chat(String m) { if(mc.thePlayer!=null) mc.thePlayer.addChatMessage(new ChatComponentText("\\u00a77[\\u00a7cEclipse\\u00a77] \\u00a7f"+m)); }
    protected void error(String m) { if(mc.thePlayer!=null) mc.thePlayer.addChatMessage(new ChatComponentText("\\u00a77[\\u00a7cEclipse\\u00a77] \\u00a7c"+m)); }
}
"""

COMMAND_MANAGER_JAVA = """package me.eclipse.command;

import me.eclipse.Eclipse;
import me.eclipse.utils.Logger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommandManager {
    private final List<Command> cmds = new ArrayList<>();
    public CommandManager() {
        cmds.add(new CommandToggle()); cmds.add(new CommandBind()); cmds.add(new CommandFriend());
        cmds.add(new CommandConfig()); cmds.add(new CommandHelp()); cmds.add(new CommandWatchdog());
    }
    public void handleCommand(String msg) {
        if(!msg.startsWith(Eclipse.commandPrefix)) return;
        String[] p = msg.substring(Eclipse.commandPrefix.length()).split(" ");
        String cn = p[0]; String[] args = Arrays.copyOfRange(p, 1, p.length);
        for(Command c : cmds) { if(c.matches(cn)) { try{c.execute(args);}catch(Exception e){Logger.log("Err:"+e);} return; } }
        Logger.log("Unknown: " + cn);
    }
    public List<Command> getCommands() { return cmds; }
}
"""

COMMAND_TOGGLE = """package me.eclipse.command;
import me.eclipse.Eclipse;
import me.eclipse.module.Module;
public class CommandToggle extends Command {
    public CommandToggle() { super("toggle", "Toggle module", "t"); }
    public void execute(String[] a) {
        if(a.length<1){error("Usage: .toggle <module>");return;}
        Module m = Eclipse.instance.moduleManager.getModule(a[0]);
        if(m==null){error("Not found: "+a[0]);return;}
        m.toggle(); chat(m.getName()+" "+(m.isEnabled()?"enabled":"disabled"));
    }
}
"""

COMMAND_HELP = """package me.eclipse.command;
import me.eclipse.Eclipse;
public class CommandHelp extends Command {
    public CommandHelp() { super("help", "Show commands"); }
    public void execute(String[] a) {
        chat("\\u00a7cCommands:");
        for(Command c : Eclipse.instance.commandManager.getCommands()) chat("  \\u00a77."+c.getName()+" - "+c.description);
    }
}
"""

COMMAND_BIND = """package me.eclipse.command;
public class CommandBind extends Command {
    public CommandBind() { super("bind", "Bind module"); }
    public void execute(String[] a) { chat("Usage: .bind <module> <key>"); }
}
"""

COMMAND_FRIEND = """package me.eclipse.command;
import me.eclipse.Eclipse;
public class CommandFriend extends Command {
    public CommandFriend() { super("friend", "Manage friends"); }
    public void execute(String[] a) {
        if(a.length<2){chat("Usage: .friend <add/remove> <name>");return;}
        if(a[0].equalsIgnoreCase("add")){Eclipse.instance.friendManager.addFriend(a[1]);chat("Added: "+a[1]);}
        else if(a[0].equalsIgnoreCase("remove")){Eclipse.instance.friendManager.removeFriend(a[1]);chat("Removed: "+a[1]);}
    }
}
"""

COMMAND_CONFIG = """package me.eclipse.command;
public class CommandConfig extends Command {
    public CommandConfig() { super("config", "Manage configs"); }
    public void execute(String[] a) { chat("Usage: .config <save/load> <name>"); }
}
"""

COMMAND_WATCHDOG = """package me.eclipse.command;
import me.eclipse.Eclipse;
import me.eclipse.module.watchdog.WDProfile;
public class CommandWatchdog extends Command {
    public CommandWatchdog() { super("watchdog", "WD bypass", "wd"); }
    public void execute(String[] a) {
        if(a.length<1){chat("\\u00a7c.watchdog <profile|status>");return;}
        if(a[0].equals("profile")&&a.length>1){
            WDProfile p=Eclipse.instance.moduleManager.getModule(WDProfile.class);
            if(p!=null){p.getSetting("Profile").setValue(a[1]);chat("Profile: "+a[1]);}
        }else if(a[0].equals("status")){chat("WD modules loaded");}
    }
}
"""

# ═══════════════════════════════════════════════════════════════
# MODULE STUB GENERATOR
# ═══════════════════════════════════════════════════════════════

def make_module(name, cat, desc, key=0):
    return f"""package me.eclipse.module.{cat.lower()};

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

public class {name} extends Module {{
    public {name}() {{
        super("{name}", "{desc}", Category.{cat.upper()}, {key});
    }}
    @Override public void onEnable() {{ super.onEnable(); }}
    @Override public void onDisable() {{ super.onDisable(); }}
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent e) {{
        if(e.phase != TickEvent.Phase.START) return;
        // TODO: Implement {name}
    }}
}}
"""

def make_mixin(name, target):
    return f"""package me.eclipse.mixin;

import me.eclipse.Eclipse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({target}.class)
public class {name} {{
    @Inject(method = "func_XXXXX", at = @At("HEAD"), cancellable = true)
    private void hook(CallbackInfo ci) {{
        // TODO: Implement {name}
    }}
}}
"""

# ═══════════════════════════════════════════════════════════════
# C++ INJECTOR
# ═══════════════════════════════════════════════════════════════

CMAKE_FILE = r"""cmake_minimum_required(VERSION 3.20)
project(EclipseInjector)
set(CMAKE_CXX_STANDARD 17)
set(SOURCES src/main.cpp src/injector.cpp src/hooks.cpp)
add_library(Eclipse SHARED ${SOURCES})
target_link_libraries(Eclipse PRIVATE mincore shlwapi dbghelp)
add_executable(EclipseInjector src/injector_main.cpp)
target_link_libraries(EclipseInjector PRIVATE shlwapi)
"""

INJECTOR_H = r"""#pragma once
#include <Windows.h>
#include <TlHelp32.h>
#include <string>
namespace Eclipse {
    class Injector {
    public:
        static bool InjectDLL(DWORD pid, const std::wstring& dll);
        static bool InjectDLL(const std::wstring& proc, const std::wstring& dll);
        static DWORD FindProcess(const std::wstring& name);
        static bool IsInjected(DWORD pid, const std::wstring& dll);
    private:
        static bool LoadLibraryInject(DWORD pid, const std::wstring& dll);
    };
}
"""

INJECTOR_CPP = r"""#include "injector.h"
#include <iostream>
namespace Eclipse {
    bool Injector::LoadLibraryInject(DWORD pid, const std::wstring& dll) {
        HANDLE hp = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
        if (!hp) return false;
        size_t sz = (dll.length()+1)*sizeof(wchar_t);
        uintptr_t pa = (uintptr_t)VirtualAllocEx(hp,0,sz,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
        if (!pa) { CloseHandle(hp); return false; }
        WriteProcessMemory(hp,(void*)pa,dll.c_str(),sz,nullptr);
        HMODULE k32 = GetModuleHandleW(L"kernel32.dll");
        uintptr_t ll = (uintptr_t)GetProcAddress(k32,"LoadLibraryW");
        HANDLE ht = CreateRemoteThread(hp,0,0,(LPTHREAD_START_ROUTINE)ll,(void*)pa,0,0);
        if (!ht) { VirtualFreeEx(hp,(void*)pa,0,MEM_RELEASE); CloseHandle(hp); return false; }
        WaitForSingleObject(ht,INFINITE);
        VirtualFreeEx(hp,(void*)pa,0,MEM_RELEASE); CloseHandle(ht); CloseHandle(hp);
        return true;
    }
    bool Injector::InjectDLL(DWORD pid, const std::wstring& dll) { return LoadLibraryInject(pid,dll); }
    bool Injector::InjectDLL(const std::wstring& proc, const std::wstring& dll) {
        DWORD pid = FindProcess(proc); return pid ? InjectDLL(pid,dll) : false;
    }
    DWORD Injector::FindProcess(const std::wstring& name) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
        if (snap==INVALID_HANDLE_VALUE) return 0;
        PROCESSENTRY32W e; e.dwSize=sizeof(e); DWORD r=0;
        if (Process32FirstW(snap,&e)) { do { if(_wcsicmp(e.szExeFile,name.c_str())==0){r=e.th32ProcessID;break;} } while(Process32NextW(snap,&e)); }
        CloseHandle(snap); return r;
    }
    bool Injector::IsInjected(DWORD pid, const std::wstring& dll) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid);
        if (snap==INVALID_HANDLE_VALUE) return false;
        MODULEENTRY32W e; e.dwSize=sizeof(e); bool f=false;
        if (Module32FirstW(snap,&e)) { do { if(_wcsicmp(e.szModule,dll.c_str())==0){f=true;break;} } while(Module32NextW(snap,&e)); }
        CloseHandle(snap); return f;
    }
}
"""

INJECTOR_MAIN = r"""#include <Windows.h>
#include <iostream>
#include "injector.h"
int main() {
    SetConsoleTitleW(L"Eclipse Injector 2.0");
    std::cout << "\n  Eclipse Injector v2.0 | 1.8.9\n\n  Searching for Minecraft...\n";
    DWORD pid = Eclipse::Injector::FindProcess(L"javaw.exe");
    if (!pid) {
        HWND w = FindWindowW(L"LWJGL",0);
        if (!w) w = FindWindowW(0,L"Minecraft 1.8.9");
        if (w) GetWindowThreadProcessId(w,&pid);
    }
    if (!pid) { std::cout << "  [!] Minecraft not found!\n\n"; std::cin.get(); return 1; }
    std::cout << "  [+] Found PID: " << pid << "\n";
    wchar_t exepath[MAX_PATH]; GetModuleFileNameW(0,exepath,MAX_PATH);
    std::wstring dll = exepath;
    size_t ls = dll.find_last_of(L"\\");
    if (ls!=std::wstring::npos) dll = dll.substr(0,ls) + L"\\Eclipse.dll";
    else dll = L"Eclipse.dll";
    if (Eclipse::Injector::IsInjected(pid,L"Eclipse.dll")) { std::cout << "  [!] Already injected!\n\n"; std::cin.get(); return 0; }
    std::cout << "  Injecting...\n";
    bool ok = Eclipse::Injector::InjectDLL(pid,dll);
    if (ok) { std::cout << "  [+] Injected! GUI: RSHIFT\n"; }
    else { std::cout << "  [!] Failed!\n"; }
    std::cout << "\n  Press any key..."; std::cin.get();
    return ok ? 0 : 1;
}
"""

HOOKS_CPP = r"""#include <Windows.h>
#include <iostream>
#include <unordered_map>
namespace Eclipse {
    static std::unordered_map<std::string, void*> g_hooks;
    class VMTHook {
        uintptr_t** vt; uintptr_t* orig; uintptr_t* newvt; int sz;
    public:
        VMTHook(void* obj) {
            vt = (uintptr_t**)obj; orig = *vt; sz=0;
            while(!IsBadCodePtr((FARPROC)orig[sz]) && sz<1000) sz++;
            newvt = new uintptr_t[sz]; memcpy(newvt,orig,sz*sizeof(uintptr_t)); *vt=newvt;
        }
        ~VMTHook() { if(vt&&orig)*vt=orig; delete[]newvt; }
        void Hook(int i, void* d) { if(i>=0&&i<sz) newvt[i]=(uintptr_t)d; }
        void* GetOrig(int i) { return (void*)orig[i]; }
    };
}
"""

MAIN_CPP = r"""#include <Windows.h>
BOOL APIENTRY DllMain(HMODULE h, DWORD r, LPVOID) {
    if (r==DLL_PROCESS_ATTACH) DisableThreadLibraryCalls(h);
    return TRUE;
}
"""

# ═══════════════════════════════════════════════════════════════
# MODULE LISTS
# ═══════════════════════════════════════════════════════════════

COMBAT_MODS = [
    ("KillAura","Attacks nearby entities",0x52),("Velocity","Reduces knockback",0),
    ("Criticals","Critical hits",0),("AutoClicker","Auto clicking",0),
    ("Reach","Extends reach",0),("CPSLimit","Limits CPS",0),
    ("BowAimbot","Aims bow",0),("AutoPot","Throws pots",0),
    ("AutoSoup","Eats soup",0),("AutoHeal","Auto heal",0),
    ("AntiBot","Filters bots",0),("Backtrack","Lag exploit",0),("TargetStrafe","Strafes target",0),
]
MOVE_MODS = [
    ("Speed","Moves faster",0x56),("Fly","Flight",0x47),("LongJump","Jump further",0),
    ("NoSlow","No slowdown",0),("Strafe","Air strafe",0),("Spider","Climb walls",0),
    ("Step","Step up",0),("HighJump","Jump higher",0),("LiquidWalk","Walk liquid",0),
    ("Jesus","Walk water",0),("SafeWalk","Safe walk",0),("AirJump","Air jump",0),("Timer","Game speed",0),
]
PLAYER_MODS = [
    ("Scaffold","Block placement",0x42),("Tower","Build up",0),("AutoArmor","Best armor",0),
    ("ChestStealer","Steal chests",0),("InvManager","Manage inv",0),("AutoTool","Best tool",0),
    ("AutoFish","Auto fish",0),("AutoGG","Say GG",0),("AutoPlay","Auto queue",0),
    ("AntiVoid","No void",0),("Blink","Hold packets",0),("Phase","Phase blocks",0),
    ("Disabler","Disable AC",0),("Freecam","Free cam",0),
]
RENDER_MODS = [
    ("ClickGUI","Click GUI",0x3F),("HUD","HUD overlay",0),("ArrayListMod","Module list",0),
    ("Keystrokes","Show keys",0),("CPSCounter","CPS display",0),("TargetHUD","Target info",0),
    ("NameTags","Name tags",0),("Tracers","Entity lines",0),("Radar","Entity radar",0),
    ("BlockOverlay","Block highlight",0),("Breadcrumbs","Trail",0),("JumpCircle","Jump ring",0),
    ("ChinaHat","Pyramid",0),("StorageESP","Chest ESP",0),("ItemESP","Item ESP",0),
    ("ProjectileESP","Proj ESP",0),("Chams","Entity chams",0),("ESP","Entity ESP",0),
    ("Trajectories","Trajectory",0),("Fullbright","Full bright",0),("Xray","See blocks",0),
    ("ItemPhysics","Item physics",0),("Animations","Custom anims",0),("NoRender","Hide elements",0),
]
WD_MODS = [
    ("WDSpeed","WD speed",0),("WDScaffold","WD scaffold",0),("WDKillAura","WD combat",0),
    ("WDMovement","WD movement",0),("WDNoSlow","WD noslow",0),("WDVelocity","WD velocity",0),
    ("WDTimer","WD timer",0),("WDDisabler","WD disable",0),("WDMacro","WD macro",0),
    ("WDProfile","WD profile",0),("WDFingerprint","WD fingerprint",0),
]
MISC_MODS = [
    ("Spammer","Spam chat",0),("MidClick","Mid friend",0),("AutoRespawn","Auto respawn",0),
    ("SkinFlicker","Skin flicker",0),("NameProtect","Hide name",0),("LootFilter","Filter loot",0),
    ("PearlPhaser","Pearl phase",0),("AntiHunger","No hunger",0),("PortalMenu","Portal menu",0),
    ("NoRotateSet","Block rot",0),("PacketLimiter","Limit pkts",0),("SessionInfo","Session info",0),
]

MIXINS = [
    ("MixinMinecraft","net.minecraft.client.Minecraft"),
    ("MixinEntity","net.minecraft.entity.Entity"),
    ("MixinEntityPlayerSP","net.minecraft.client.entity.EntityPlayerSP"),
    ("MixinPlayerControllerMP","net.minecraft.client.multiplayer.PlayerControllerMP"),
    ("MixinNetHandlerPlayClient","net.minecraft.client.network.NetHandlerPlayClient"),
    ("MixinNetworkManager","net.minecraft.network.NetworkManager"),
    ("MixinAbstractClientPlayer","net.minecraft.client.entity.AbstractClientPlayer"),
    ("MixinWorldRenderer","net.minecraft.client.renderer.WorldRenderer"),
    ("MixinRenderManager","net.minecraft.client.renderer.entity.RenderManager"),
    ("MixinRendererLivingEntity","net.minecraft.client.renderer.entity.RendererLivingEntity"),
    ("MixinGuiIngame","net.minecraft.client.gui.GuiIngame"),
    ("MixinGuiScreen","net.minecraft.client.gui.GuiScreen"),
]

# ═══════════════════════════════════════════════════════════════
# GENERATOR
# ═══════════════════════════════════════════════════════════════

class Generator:
    def __init__(self, out):
        self.out = Path(out)
        self.files = []
        self.count = 0
    
    def add(self, path, content):
        self.files.append((path, content))
    
    def build(self):
        # Build files
        self.add("build.gradle", BUILD_GRADLE)
        self.add("settings.gradle", SETTINGS_GRADLE)
        self.add("gradle.properties", GRADLE_PROPS)
        self.add(".gitignore", GITIGNORE)
        self.add("README.md", README)
        self.add("src/main/resources/mcmod.info", MCMOD_INFO)
        self.add("src/main/resources/mixin.eclipse.json", MIXIN_JSON)
        
        # Core
        self.add("src/main/java/me/eclipse/Eclipse.java", ECLIPSE_MAIN)
        self.add("src/main/java/me/eclipse/core/EventBus.java", EVENT_BUS)
        self.add("src/main/java/me/eclipse/core/EventHandler.java", EVENT_HANDLER)
        self.add("src/main/java/me/eclipse/core/Cancellable.java", CANCELLABLE)
        self.add("src/main/java/me/eclipse/core/ModuleManager.java", MODULE_MANAGER)
        self.add("src/main/java/me/eclipse/core/RotationManager.java", ROTATION_MANAGER)
        self.add("src/main/java/me/eclipse/core/EclipseMixinPlugin.java", MIXIN_PLUGIN)
        self.add("src/main/java/me/eclipse/core/ConfigManager.java", CONFIG_MANAGER)
        self.add("src/main/java/me/eclipse/core/FriendManager.java", FRIEND_MANAGER)
        self.add("src/main/java/me/eclipse/core/WaypointManager.java", WAYPOINT_MANAGER)
        
        # Module base
        self.add("src/main/java/me/eclipse/module/Module.java", MODULE_BASE)
        self.add("src/main/java/me/eclipse/module/ModuleInfo.java", MODULE_INFO)
        self.add("src/main/java/me/eclipse/module/enums/Category.java", CATEGORY)
        
        # Settings
        self.add("src/main/java/me/eclipse/module/setting/Setting.java", SETTING_BASE)
        self.add("src/main/java/me/eclipse/module/setting/SettingBoolean.java", SETTING_BOOL)
        self.add("src/main/java/me/eclipse/module/setting/SettingDouble.java", SETTING_DOUBLE)
        self.add("src/main/java/me/eclipse/module/setting/SettingInteger.java", SETTING_INT)
        self.add("src/main/java/me/eclipse/module/setting/SettingMode.java", SETTING_MODE)
        self.add("src/main/java/me/eclipse/module/setting/SettingColor.java", SETTING_COLOR)
        self.add("src/main/java/me/eclipse/module/setting/SettingFloat.java", SETTING_FLOAT)
        
        # Network
        self.add("src/main/java/me/eclipse/network/PacketHandler.java", PACKET_HANDLER)
        
        # Utils
        self.add("src/main/java/me/eclipse/utils/Logger.java", LOGGER)
        self.add("src/main/java/me/eclipse/utils/RenderUtils.java", RENDER_UTILS)
        self.add("src/main/java/me/eclipse/utils/RandomUtils.java", RANDOM_UTILS)
        self.add("src/main/java/me/eclipse/utils/AnimationUtils.java", ANIM_UTILS)
        self.add("src/main/java/me/eclipse/utils/EntityUtils.java", ENTITY_UTILS)
        self.add("src/main/java/me/eclipse/utils/MathUtils.java", MATH_UTILS)
        self.add("src/main/java/me/eclipse/utils/BlockUtils.java", BLOCK_UTILS)
        self.add("src/main/java/me/eclipse/utils/BlurUtils.java", BLUR_UTILS)
        
        # Font
        self.add("src/main/java/me/eclipse/gui/font/FontRenderer.java", FONT_RENDERER)
        
        # Commands
        self.add("src/main/java/me/eclipse/command/Command.java", COMMAND_BASE)
        self.add("src/main/java/me/eclipse/command/CommandManager.java", COMMAND_MANAGER_JAVA)
        self.add("src/main/java/me/eclipse/command/CommandToggle.java", COMMAND_TOGGLE)
        self.add("src/main/java/me/eclipse/command/CommandHelp.java", COMMAND_HELP)
        self.add("src/main/java/me/eclipse/command/CommandBind.java", COMMAND_BIND)
        self.add("src/main/java/me/eclipse/command/CommandFriend.java", COMMAND_FRIEND)
        self.add("src/main/java/me/eclipse/command/CommandConfig.java", COMMAND_CONFIG)
        self.add("src/main/java/me/eclipse/command/CommandWatchdog.java", COMMAND_WATCHDOG)
        
        # Modules
        for n,d,k in COMBAT_MODS: self.add(f"src/main/java/me/eclipse/module/combat/{n}.java", make_module(n,"combat",d,k))
        for n,d,k in MOVE_MODS: self.add(f"src/main/java/me/eclipse/module/movement/{n}.java", make_module(n,"movement",d,k))
        for n,d,k in PLAYER_MODS: self.add(f"src/main/java/me/eclipse/module/player/{n}.java", make_module(n,"player",d,k))
        for n,d,k in RENDER_MODS: self.add(f"src/main/java/me/eclipse/module/render/{n}.java", make_module(n,"render",d,k))
        for n,d,k in WD_MODS: self.add(f"src/main/java/me/eclipse/module/watchdog/{n}.java", make_module(n,"watchdog",d,k))
        for n,d,k in MISC_MODS: self.add(f"src/main/java/me/eclipse/module/misc/{n}.java", make_module(n,"misc",d,k))
        
        # Mixins
        for n,t in MIXINS: self.add(f"src/main/java/me/eclipse/mixin/{n}.java", make_mixin(n,t))
        
        # Injector
        self.add("eclipse-injector/CMakeLists.txt", CMAKE_FILE)
        self.add("eclipse-injector/src/injector.h", INJECTOR_H)
        self.add("eclipse-injector/src/injector.cpp", INJECTOR_CPP)
        self.add("eclipse-injector/src/injector_main.cpp", INJECTOR_MAIN)
        self.add("eclipse-injector/src/hooks.cpp", HOOKS_CPP)
        self.add("eclipse-injector/src/main.cpp", MAIN_CPP)
    
    def generate(self):
        self.out.mkdir(parents=True, exist_ok=True)
        for path, content in self.files:
            fp = self.out / path
            fp.parent.mkdir(parents=True, exist_ok=True)
            with open(fp, "w", encoding="utf-8") as f:
                f.write(content)
            self.count += 1
        return True
    
    def zip(self):
        zp = str(self.out) + ".zip"
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(self.out):
                for f in files:
                    fp = Path(root) / f
                    zf.write(fp, fp.relative_to(self.out.parent))
        return zp

def main():
    parser = argparse.ArgumentParser(description="Eclipse Client Generator")
    parser.add_argument("--output", "-o", default="./EclipseClient", help="Output dir")
    parser.add_argument("--zip", "-z", action="store_true", help="Create zip")
    parser.add_argument("--clean", "-c", action="store_true", help="Clean first")
    args = parser.parse_args()
    
    banner()
    
    if args.clean and os.path.exists(args.output):
        info(f"Cleaning {args.output}")
        shutil.rmtree(args.output)
    
    gen = Generator(args.output)
    info("Building file list...")
    gen.build()
    
    print(f"\n  {B}Generating...{X}\n")
    start = datetime.now()
    
    if not gen.generate():
        err("Failed!")
        sys.exit(1)
    
    ms = (datetime.now() - start).total_seconds() * 1000
    print(f"\n  {B}Done!{X}")
    ok(f"{gen.count} files created in {ms:.0f}ms")
    
    if args.zip:
        zp = gen.zip()
        ok(f"Zip: {zp}")
    
    print(f"\n  {D}Next: cd {args.output} && gradle wrapper && gradlew setupDecompWorkspace && gradlew build{X}\n")

if __name__ == "__main__":
    main()