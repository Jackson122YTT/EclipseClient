#!/usr/bin/env python3
"""
Eclipse Client 2.0 - Implementation Injector
Fills in the full module implementations into stub files

Usage:
    python inject_implementations.py [--source DIR] [--help]
"""

import os
import sys
import argparse
from pathlib import Path

# Colors
G = "\033[92m"
R = "\033[91m"
C = "\033[96m"
W = "\033[97m"
B = "\033[1m"
D = "\033[2m"
X = "\033[0m"

def ok(m): print(f"  {G}+{X} {m}")
def err(m): print(f"  {R}!{X} {m}")
def info(m): print(f"  {C}>{X} {m}")

# ═══════════════════════════════════════════════════════════════
# FULL IMPLEMENTATIONS
# ═══════════════════════════════════════════════════════════════

WD_SPEED = r"""package me.eclipse.module.watchdog;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.MathUtils;
import me.eclipse.utils.RandomUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

@ModuleInfo(name = "WDSpeed", description = "Watchdog behavioral speed bypass", 
            category = Category.WATCHDOG, keyBind = 0)
public class WDSpeed extends Module {
    private final SettingDouble speed = new SettingDouble("Speed", 1.35, 1.0, 2.0, 0.01);
    private final SettingDouble hopHeight = new SettingDouble("Hop Height", 0.12, 0.05, 0.4, 0.01);
    private final SettingInteger decelInterval = new SettingInteger("Decel Interval", 7, 4, 12, 1);
    private final SettingDouble decelAmount = new SettingDouble("Decel Amount", 0.15, 0.05, 0.4, 0.01);
    private final SettingDouble strafeBoost = new SettingDouble("Strafe Boost", 0.28, 0.1, 0.5, 0.01);
    private final SettingBoolean lowHop = new SettingBoolean("Low Hop", true);
    private final SettingInteger groundTicks = new SettingInteger("Ground Ticks", 2, 1, 4, 1);
    private final SettingInteger airTicks = new SettingInteger("Air Ticks", 3, 2, 6, 1);
    private final SettingDouble inconsistency = new SettingDouble("Inconsistency", 0.08, 0.0, 0.2, 0.01);
    
    private int tickCounter;
    private int phase;
    private double currentSpeed;
    private double lastMotionX;
    private double lastMotionZ;
    
    public WDSpeed() {
        addSetting(speed, hopHeight, decelInterval, decelAmount, strafeBoost,
                  lowHop, groundTicks, airTicks, inconsistency);
    }
    
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;
        if (!mc.thePlayer.isMoving()) return;
        if (mc.thePlayer.isInWater() || mc.thePlayer.isInLava()) return;
        
        tickCounter++;
        
        double baseSpeed = speed.getValue() + RandomUtils.nextGaussian(inconsistency.getValue());
        float yaw = mc.thePlayer.rotationYaw;
        
        switch (phase) {
            case 0:
                if (mc.thePlayer.onGround) {
                    mc.thePlayer.motionX = -MathHelper.sin((float) Math.toRadians(yaw)) * baseSpeed * 0.28;
                    mc.thePlayer.motionZ = MathHelper.cos((float) Math.toRadians(yaw)) * baseSpeed * 0.28;
                    if (tickCounter >= groundTicks.getValue()) {
                        if (lowHop.getValue()) {
                            mc.thePlayer.motionY = hopHeight.getValue() + RandomUtils.nextGaussian(0.02);
                        }
                        phase = 1;
                        tickCounter = 0;
                    }
                }
                break;
            case 1:
                if (!mc.thePlayer.onGround) {
                    double strafe = strafeBoost.getValue() + RandomUtils.nextGaussian(0.03);
                    if (mc.thePlayer.movementInput.moveStrafe != 0) {
                        yaw += (mc.thePlayer.movementInput.moveStrafe > 0 ? 90 : -90);
                        strafe *= 0.85;
                    }
                    mc.thePlayer.motionX = -MathHelper.sin((float) Math.toRadians(yaw)) * strafe;
                    mc.thePlayer.motionZ = MathHelper.cos((float) Math.toRadians(yaw)) * strafe;
                    if (tickCounter >= airTicks.getValue()) {
                        phase = 2;
                        tickCounter = 0;
                    }
                }
                break;
            case 2:
                double decel = decelAmount.getValue() + RandomUtils.nextGaussian(0.02);
                mc.thePlayer.motionX *= (1.0 - decel);
                mc.thePlayer.motionZ *= (1.0 - decel);
                if (tickCounter >= 1 || mc.thePlayer.onGround) {
                    phase = 0;
                    tickCounter = 0;
                }
                break;
        }
        lastMotionX = mc.thePlayer.motionX;
        lastMotionZ = mc.thePlayer.motionZ;
    }
    
    @Override
    public void onDisable() {
        if (mc.thePlayer != null) {
            mc.thePlayer.motionX = 0;
            mc.thePlayer.motionZ = 0;
        }
        tickCounter = 0;
        phase = 0;
    }
}
"""

WD_SCAFFOLD = r"""package me.eclipse.module.watchdog;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.*;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.*;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

@ModuleInfo(name = "WDScaffold", description = "Watchdog human bridge simulation", 
            category = Category.WATCHDOG, keyBind = 0)
public class WDScaffold extends Module {
    private final SettingDouble expand = new SettingDouble("Expand", 0.0, 0.0, 5.0, 0.1);
    private final SettingInteger delay = new SettingInteger("Delay", 100, 60, 180, 5);
    private final SettingDouble yawJitter = new SettingDouble("Yaw Jitter", 3.5, 0.0, 8.0, 0.5);
    private final SettingDouble missChance = new SettingDouble("Miss Chance", 0.06, 0.0, 0.2, 0.01);
    private final SettingBoolean eagle = new SettingBoolean("Eagle", true);
    private final SettingBoolean tower = new SettingBoolean("Tower", false);
    private final SettingMode rotationMode = new SettingMode("Rotation", 
        new String[]{"Smooth", "Instant", "None"}, "Smooth");
    private final SettingDouble rotationSpeed = new SettingDouble("Rotation Speed", 45.0, 10.0, 90.0, 5.0);
    
    private long lastPlaceTime;
    private int slot;
    private float targetYaw, targetPitch;
    private boolean shouldSneak;
    private int consecutiveMisses;
    
    public WDScaffold() {
        addSetting(expand, delay, yawJitter, missChance, eagle, tower,
                  rotationMode, rotationSpeed);
    }
    
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (mc.thePlayer == null) return;
        
        slot = findBlockSlot();
        if (slot == -1) return;
        
        BlockPos target = getTargetBlock();
        if (target == null) return;
        
        if (eagle.getValue() && shouldEagle()) {
            mc.thePlayer.setSprinting(false);
            mc.gameSettings.keyBindSneak.pressed = true;
            shouldSneak = true;
        } else if (shouldSneak) {
            mc.gameSettings.keyBindSneak.pressed = false;
            shouldSneak = false;
        }
        
        long currentTime = System.currentTimeMillis();
        int variance = RandomUtils.nextInt(-30, 30);
        if (currentTime - lastPlaceTime < delay.getValue() + variance) return;
        
        if (Math.random() < missChance.getValue() && consecutiveMisses < 2) {
            consecutiveMisses++;
            lastPlaceTime = currentTime;
            return;
        }
        consecutiveMisses = 0;
        
        float[] rotations = calculateRotations(target);
        targetYaw = rotations[0] + (float) RandomUtils.nextGaussian(yawJitter.getValue());
        targetPitch = rotations[1];
        
        if (rotationMode.getValue().equals("Smooth")) {
            float speed = rotationSpeed.getValue().floatValue() * 0.017f;
            mc.thePlayer.rotationYaw = lerpAngle(mc.thePlayer.rotationYaw, targetYaw, speed);
            mc.thePlayer.rotationPitch = lerpAngle(mc.thePlayer.rotationPitch, targetPitch, speed);
        } else if (rotationMode.getValue().equals("Instant")) {
            mc.thePlayer.rotationYaw = targetYaw;
            mc.thePlayer.rotationPitch = targetPitch;
        }
        
        if (mc.thePlayer.inventory.currentItem != slot) {
            mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(slot));
            mc.thePlayer.inventory.currentItem = slot;
        }
        
        EnumFacing face = getPlaceFace(target);
        if (face != null) {
            BlockPos placePos = target.offset(face);
            mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(
                placePos, face.getOpposite(), mc.thePlayer.getHeldItem(), 0.5f, 1.0f, 0.5f));
            mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, 
                mc.thePlayer.getHeldItem(), placePos, face.getOpposite(), 
                new Vec3(placePos).addVector(0.5, 1.0, 0.5));
            lastPlaceTime = currentTime;
        }
        
        if (tower.getValue() && mc.gameSettings.keyBindJump.isKeyDown()) {
            if (mc.thePlayer.onGround) {
                mc.thePlayer.motionY = 0.42;
                mc.thePlayer.motionY += RandomUtils.nextGaussian(0.01);
            }
        }
    }
    
    private BlockPos getTargetBlock() {
        double expandVal = expand.getValue();
        double x = mc.thePlayer.posX + Math.cos(Math.toRadians(mc.thePlayer.rotationYaw + 90)) * expandVal;
        double z = mc.thePlayer.posZ + Math.sin(Math.toRadians(mc.thePlayer.rotationYaw + 90)) * expandVal;
        return new BlockPos(Math.floor(x), Math.floor(mc.thePlayer.posY) - 1, Math.floor(z));
    }
    
    private EnumFacing getPlaceFace(BlockPos pos) {
        for (EnumFacing face : EnumFacing.values()) {
            if (face == EnumFacing.UP) continue;
            BlockPos adjacent = pos.offset(face);
            Block block = mc.theWorld.getBlockState(adjacent).getBlock();
            if (!block.isAir(mc.theWorld, adjacent) && block != Blocks.water) return face;
        }
        return null;
    }
    
    private float[] calculateRotations(BlockPos pos) {
        double x = pos.getX() + 0.5 - mc.thePlayer.posX;
        double y = pos.getY() + 0.5 - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double z = pos.getZ() + 0.5 - mc.thePlayer.posZ;
        float yaw = (float) Math.toDegrees(Math.atan2(z, x)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(y, Math.sqrt(x * x + z * z)));
        return new float[]{yaw, pitch};
    }
    
    private boolean shouldEagle() {
        return !mc.theWorld.getBlockState(new BlockPos(
            Math.floor(mc.thePlayer.posX), Math.floor(mc.thePlayer.posY) - 1,
            Math.floor(mc.thePlayer.posZ))).getBlock().isFullBlock();
    }
    
    private int findBlockSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.thePlayer.inventory.mainInventory[i];
            if (stack != null && stack.getItem() instanceof ItemBlock) return i;
        }
        return -1;
    }
    
    private float lerpAngle(float from, float to, float speed) {
        float diff = net.minecraft.util.MathHelper.wrapAngleTo180_float(to - from);
        if (Math.abs(diff) < speed) return to;
        return from + (diff > 0 ? speed : -speed);
    }
    
    @Override
    public void onDisable() {
        if (shouldSneak) mc.gameSettings.keyBindSneak.pressed = false;
    }
}
"""

WD_KILL_AURA = r"""package me.eclipse.module.watchdog;

import me.eclipse.core.EventBus;
import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.*;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

import java.util.*;
import java.util.stream.Collectors;

@ModuleInfo(name = "WDKillAura", description = "Watchdog legit combat simulation", 
            category = Category.WATCHDOG, keyBind = 0)
public class WDKillAura extends Module {
    private final SettingDouble range = new SettingDouble("Range", 3.2, 1.0, 6.0, 0.1);
    private final SettingDouble fov = new SettingDouble("FOV", 180.0, 30.0, 360.0, 10.0);
    private final SettingInteger switchDelay = new SettingInteger("Switch Delay", 450, 200, 800, 50);
    private final SettingDouble rotationSpeed = new SettingDouble("Rot Speed", 55.0, 10.0, 180.0, 5.0);
    private final SettingDouble missChance = new SettingDouble("Miss Chance", 0.08, 0.0, 0.25, 0.01);
    private final SettingInteger minCPS = new SettingInteger("Min CPS", 7, 1, 20, 1);
    private final SettingInteger maxCPS = new SettingInteger("Max CPS", 11, 1, 20, 1);
    private final SettingBoolean autoBlock = new SettingBoolean("Auto Block", false);
    private final SettingBoolean criticals = new SettingBoolean("Criticals", true);
    private final SettingMode targetMode = new SettingMode("Target", 
        new String[]{"Closest", "Health", "Angle"}, "Closest");
    private final SettingBoolean players = new SettingBoolean("Players", true);
    private final SettingBoolean mobs = new SettingBoolean("Mobs", false);
    private final SettingBoolean animals = new SettingBoolean("Animals", false);
    private final SettingBoolean invisibles = new SettingBoolean("Invisibles", false);
    
    private EntityLivingBase currentTarget;
    private long lastSwitchTime;
    private long lastAttackTime;
    private float[] serverRotations = new float[2];
    private double[] cpsPattern;
    private int cpsIndex;
    private boolean shouldMiss;
    private int consecutiveHits;
    
    public WDKillAura() {
        addSetting(range, fov, switchDelay, rotationSpeed, missChance,
                  minCPS, maxCPS, autoBlock, criticals, targetMode,
                  players, mobs, animals, invisibles);
        generateCPSPattern();
    }
    
    private void generateCPSPattern() {
        int length = RandomUtils.nextInt(20, 40);
        cpsPattern = new double[length];
        double baseCPS = (minCPS.getValue() + maxCPS.getValue()) / 2.0;
        double variance = (maxCPS.getValue() - minCPS.getValue()) / 4.0;
        for (int i = 0; i < length; i++) {
            double cluster = Math.sin(i * 0.3) * variance * 0.5;
            cpsPattern[i] = 1000.0 / (baseCPS + RandomUtils.nextGaussian(variance) + cluster);
        }
        cpsIndex = 0;
    }
    
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (mc.thePlayer == null) return;
        
        EntityLivingBase target = findTarget();
        
        if (target != currentTarget) {
            if (System.currentTimeMillis() - lastSwitchTime < switchDelay.getValue()) {
                target = currentTarget;
            } else if (target != null) {
                currentTarget = target;
                lastSwitchTime = System.currentTimeMillis();
                consecutiveHits = 0;
            }
        }
        
        if (currentTarget == null) return;
        
        float[] targetRotations = getTargetRotations(currentTarget);
        float rotSpeed = (float) (rotationSpeed.getValue() * 0.017f);
        targetRotations[0] += (float) RandomUtils.nextGaussian(0.5);
        targetRotations[1] += (float) RandomUtils.nextGaussian(0.3);
        
        serverRotations[0] = lerpAngle(serverRotations[0], targetRotations[0], rotSpeed);
        serverRotations[1] = lerpAngle(serverRotations[1], targetRotations[1], rotSpeed);
        
        mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(
            serverRotations[0], serverRotations[1], mc.thePlayer.onGround));
        
        long currentTime = System.currentTimeMillis();
        double clickInterval = cpsPattern[cpsIndex % cpsPattern.length];
        
        if (currentTime - lastAttackTime >= clickInterval) {
            if (consecutiveHits > 3 && Math.random() < missChance.getValue()) {
                shouldMiss = true;
                consecutiveHits = 0;
            }
            
            if (!shouldMiss) {
                attack(currentTarget);
                consecutiveHits++;
            } else {
                mc.thePlayer.swingItem();
                shouldMiss = false;
            }
            
            lastAttackTime = currentTime;
            cpsIndex++;
            
            if (cpsIndex % 100 == 0) generateCPSPattern();
        }
        
        if (autoBlock.getValue() && mc.thePlayer.getHeldItem() != null) {
            mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem());
        }
    }
    
    private EntityLivingBase findTarget() {
        List<EntityLivingBase> validTargets = new ArrayList<>();
        
        for (Entity entity : mc.theWorld.loadedEntityList) {
            if (!(entity instanceof EntityLivingBase)) continue;
            if (entity == mc.thePlayer) continue;
            if (entity.isDead) continue;
            if (!invisibles.getValue() && entity.isInvisible()) continue;
            
            double dist = mc.thePlayer.getDistanceToEntity(entity);
            if (dist > range.getValue()) continue;
            
            if (entity instanceof EntityPlayer && !players.getValue()) continue;
            if (EntityUtils.isMob(entity) && !mobs.getValue()) continue;
            if (EntityUtils.isAnimal(entity) && !animals.getValue()) continue;
            
            if (fov.getValue() < 360) {
                double angleDiff = getAngleDifference(mc.thePlayer.rotationYaw, getRotations(entity)[0]);
                if (Math.abs(angleDiff) > fov.getValue() / 2) continue;
            }
            
            validTargets.add((EntityLivingBase) entity);
        }
        
        if (validTargets.isEmpty()) return null;
        
        switch (targetMode.getValue()) {
            case "Closest":
                validTargets.sort(Comparator.comparingDouble(e -> mc.thePlayer.getDistanceToEntity(e)));
                break;
            case "Health":
                validTargets.sort(Comparator.comparingDouble(EntityLivingBase::getHealth));
                break;
            case "Angle":
                validTargets.sort(Comparator.comparingDouble(
                    e -> Math.abs(getAngleDifference(mc.thePlayer.rotationYaw, getRotations(e)[0]))));
                break;
        }
        return validTargets.get(0);
    }
    
    private void attack(EntityLivingBase target) {
        if (criticals.getValue() && mc.thePlayer.onGround) {
            mc.thePlayer.motionY = 0.1;
            mc.thePlayer.fallDistance = 0.1f;
        }
        mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(target, C02PacketUseEntity.Action.ATTACK));
        mc.thePlayer.attackTargetEntityWithCurrentItem(target);
        mc.thePlayer.swingItem();
    }
    
    private float[] getTargetRotations(Entity entity) {
        double diffX = entity.posX - mc.thePlayer.posX;
        double diffY = (entity.posY + entity.getEyeHeight() * 0.8) 
                      - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double diffZ = entity.posZ - mc.thePlayer.posZ;
        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(diffY, Math.sqrt(diffX * diffX + diffZ * diffZ)));
        return new float[]{
            net.minecraft.util.MathHelper.wrapAngleTo180_float(yaw),
            net.minecraft.util.MathHelper.clamp_float(pitch, -90f, 90f)
        };
    }
    
    private float[] getRotations(Entity entity) {
        double diffX = entity.posX - mc.thePlayer.posX;
        double diffZ = entity.posZ - mc.thePlayer.posZ;
        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90f;
        return new float[]{net.minecraft.util.MathHelper.wrapAngleTo180_float(yaw), 0f};
    }
    
    private float getAngleDifference(float from, float to) {
        return net.minecraft.util.MathHelper.wrapAngleTo180_float(to - from);
    }
    
    private float lerpAngle(float from, float to, float speed) {
        float diff = net.minecraft.util.MathHelper.wrapAngleTo180_float(to - from);
        if (Math.abs(diff) < speed) return to;
        return from + (diff > 0 ? speed : -speed);
    }
    
    @Override
    public void onEnable() {
        serverRotations[0] = mc.thePlayer.rotationYaw;
        serverRotations[1] = mc.thePlayer.rotationPitch;
    }
    
    @Override
    public void onDisable() {
        currentTarget = null;
        shouldMiss = false;
    }
}
"""

WD_VELOCITY = r"""package me.eclipse.module.watchdog;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.RandomUtils;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraftforge.fml.common.eventhandler.Event;

@ModuleInfo(name = "WDVelocity", description = "Watchdog shaped knockback", 
            category = Category.WATCHDOG, keyBind = 0)
public class WDVelocity extends Module {
    private final SettingDouble horizontalReduction = new SettingDouble("Horizontal", 0.45, 0.0, 1.0, 0.05);
    private final SettingDouble verticalReduction = new SettingDouble("Vertical", 0.55, 0.0, 1.0, 0.05);
    private final SettingInteger tickDelay = new SettingInteger("Tick Delay", 1, 0, 3, 1);
    private final SettingDouble variance = new SettingDouble("Variance", 0.15, 0.0, 0.3, 0.01);
    private final SettingBoolean perAttacker = new SettingBoolean("Per Attacker", true);
    private final SettingMode mode = new SettingMode("Mode", 
        new String[]{"Shaped", "Pulse", "Cancel Ground"}, "Shaped");
    
    private int delayCounter;
    private S12PacketEntityVelocity queuedVelocity;
    private double lastHReduction, lastVReduction;
    
    public WDVelocity() {
        addSetting(horizontalReduction, verticalReduction, tickDelay, variance, perAttacker, mode);
    }
    
    @EventHandler
    public void onVelocity(PacketEvent.Receive event) {
        if (event.getPacket() instanceof S12PacketEntityVelocity) {
            S12PacketEntityVelocity packet = (S12PacketEntityVelocity) event.getPacket();
            if (packet.getEntityID() != mc.thePlayer.getEntityId()) return;
            
            double hReduce = horizontalReduction.getValue();
            double vReduce = verticalReduction.getValue();
            
            if (perAttacker.getValue()) {
                hReduce += RandomUtils.nextGaussian(variance.getValue());
                vReduce += RandomUtils.nextGaussian(variance.getValue());
                hReduce = Math.max(0, Math.min(1, hReduce));
                vReduce = Math.max(0, Math.min(1, vReduce));
            }
            
            switch (mode.getValue()) {
                case "Shaped":
                    if (tickDelay.getValue() == 0) {
                        applyShapedVelocity(packet, hReduce, vReduce);
                    } else {
                        queuedVelocity = packet;
                        lastHReduction = hReduce;
                        lastVReduction = vReduce;
                        delayCounter = tickDelay.getValue();
                    }
                    break;
                case "Pulse":
                    if (mc.thePlayer.onGround) {
                        applyShapedVelocity(packet, hReduce, vReduce);
                    } else {
                        applyShapedVelocity(packet, hReduce * 0.3, vReduce);
                    }
                    break;
                case "Cancel Ground":
                    if (mc.thePlayer.onGround) {
                        event.setCancelled(true);
                    } else {
                        applyShapedVelocity(packet, hReduce, vReduce);
                    }
                    break;
            }
        }
    }
    
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (queuedVelocity != null && delayCounter > 0) {
            delayCounter--;
            if (delayCounter == 0) {
                applyShapedVelocity(queuedVelocity, lastHReduction, lastVReduction);
                queuedVelocity = null;
            }
        }
    }
    
    private void applyShapedVelocity(S12PacketEntityVelocity packet, double hReduce, double vReduce) {
        double motionX = packet.getMotionX() / 8000.0;
        double motionY = packet.getMotionY() / 8000.0;
        double motionZ = packet.getMotionZ() / 8000.0;
        mc.thePlayer.motionX = motionX * hReduce;
        mc.thePlayer.motionY = motionY * vReduce;
        mc.thePlayer.motionZ = motionZ * hReduce;
    }
}
"""

WD_TIMER = r"""package me.eclipse.module.watchdog;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.RandomUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Timer;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

import java.lang.reflect.Field;

@ModuleInfo(name = "WDTimer", description = "Watchdog burst timer bypass", 
            category = Category.WATCHDOG, keyBind = 0)
public class WDTimer extends Module {
    private final SettingDouble timerSpeed = new SettingDouble("Speed", 1.06, 1.0, 1.15, 0.01);
    private final SettingInteger burstTicks = new SettingInteger("Burst Ticks", 3, 1, 6, 1);
    private final SettingInteger cooldownTicks = new SettingInteger("Cooldown", 14, 8, 25, 1);
    private final SettingDouble cooldownSpeed = new SettingDouble("Cooldown Speed", 1.0, 0.95, 1.0, 0.01);
    private final SettingBoolean requireMoving = new SettingBoolean("Require Moving", true);
    
    private int tickCounter;
    private boolean inBurst;
    private Field timerField;
    
    public WDTimer() {
        addSetting(timerSpeed, burstTicks, cooldownTicks, cooldownSpeed, requireMoving);
        try {
            timerField = Minecraft.class.getDeclaredField("timer");
            timerField.setAccessible(true);
        } catch (Exception e) { e.printStackTrace(); }
    }
    
    @EventHandler
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.thePlayer == null) return;
        if (requireMoving.getValue() && !mc.thePlayer.isMoving()) {
            setTimerSpeed(1.0f);
            return;
        }
        
        tickCounter++;
        
        if (!inBurst) {
            setTimerSpeed(cooldownSpeed.getValue().floatValue());
            if (tickCounter >= cooldownTicks.getValue() + RandomUtils.nextInt(-2, 2)) {
                inBurst = true;
                tickCounter = 0;
            }
        } else {
            setTimerSpeed(timerSpeed.getValue().floatValue());
            if (tickCounter >= burstTicks.getValue() + RandomUtils.nextInt(-1, 1)) {
                inBurst = false;
                tickCounter = 0;
            }
        }
    }
    
    private void setTimerSpeed(float speed) {
        try {
            Timer timer = (Timer) timerField.get(mc);
            timer.timerSpeed = speed;
        } catch (Exception e) { }
    }
    
    @Override
    public void onDisable() {
        setTimerSpeed(1.0f);
        tickCounter = 0;
        inBurst = false;
    }
}
"""

WD_PROFILE = r"""package me.eclipse.module.watchdog;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.RandomUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

@ModuleInfo(name = "WDProfile", description = "Watchdog behavior profile manager", 
            category = Category.WATCHDOG, keyBind = 0)
public class WDProfile extends Module {
    public enum Profile {
        LEGIT_PVP("Legit PvP", 0.02, 0.03, 8, 12, 0.05),
        SEMI_RAGE("Semi-Rage", 0.06, 0.05, 9, 13, 0.08),
        GHOST("Ghost Mode", 0.01, 0.02, 7, 10, 0.03),
        HUMANIZED("Humanized", 0.08, 0.07, 6, 11, 0.12),
        RAGE_BYPASS("Rage Bypass", 0.04, 0.04, 10, 14, 0.06);
        
        public final String name;
        public final double movementInconsistency, rotationJitter, missRate;
        public final int minCPS, maxCPS;
        
        Profile(String n, double mi, double rj, int min, int max, double mr) {
            name = n; movementInconsistency = mi; rotationJitter = rj; minCPS = min; maxCPS = max; missRate = mr;
        }
    }
    
    private final SettingMode profile = new SettingMode("Profile", 
        new String[]{"Legit PvP", "Semi-Rage", "Ghost", "Humanized", "Rage Bypass"}, "Legit PvP");
    private final SettingBoolean autoApply = new SettingBoolean("Auto Apply", true);
    private final SettingBoolean wTapSim = new SettingBoolean("W-Tap Sim", true);
    private final SettingDouble wTapChance = new SettingDouble("W-Tap Chance", 0.35, 0.0, 0.8, 0.05);
    private final SettingBoolean microStutter = new SettingBoolean("Micro Stutter", true);
    private final SettingDouble stutterChance = new SettingDouble("Stutter Chance", 0.04, 0.0, 0.15, 0.01);
    private final SettingBoolean strafeVariance = new SettingBoolean("Strafe Variance", true);
    
    private int wTapCooldown;
    private boolean isStuttering;
    private int stutterTicks;
    
    public WDProfile() {
        addSetting(profile, autoApply, wTapSim, wTapChance, microStutter, stutterChance, strafeVariance);
    }
    
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (mc.thePlayer == null) return;
        
        Profile currentProfile = Profile.valueOf(profile.getValue().toUpperCase().replace(" ", "_"));
        
        if (autoApply.getValue()) applyProfileSettings(currentProfile);
        
        if (wTapSim.getValue() && mc.thePlayer.isMoving()) {
            if (wTapCooldown > 0) { wTapCooldown--; }
            else if (Math.random() < wTapChance.getValue() * 0.1) {
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
                wTapCooldown = RandomUtils.nextInt(1, 3);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), true);
            }
        }
        
        if (microStutter.getValue() && mc.thePlayer.isMoving() && !isStuttering) {
            if (Math.random() < stutterChance.getValue() * 0.05) {
                isStuttering = true;
                stutterTicks = RandomUtils.nextInt(1, 3);
            }
        }
        
        if (isStuttering) {
            mc.thePlayer.motionX *= 0.3;
            mc.thePlayer.motionZ *= 0.3;
            stutterTicks--;
            if (stutterTicks <= 0) isStuttering = false;
        }
        
        if (strafeVariance.getValue() && mc.thePlayer.movementInput.moveStrafe != 0) {
            mc.thePlayer.rotationYaw += (float) RandomUtils.nextGaussian(currentProfile.rotationJitter);
        }
    }
    
    private void applyProfileSettings(Profile p) {
        WDKillAura ka = Eclipse.instance.moduleManager.getModule(WDKillAura.class);
        if (ka != null && ka.isEnabled()) {
            ka.getSetting("Min CPS").setValue(p.minCPS);
            ka.getSetting("Max CPS").setValue(p.maxCPS);
            ka.getSetting("Miss Chance").setValue(p.missRate);
        }
        WDSpeed sp = Eclipse.instance.moduleManager.getModule(WDSpeed.class);
        if (sp != null && sp.isEnabled()) sp.getSetting("Inconsistency").setValue(p.movementInconsistency);
        WDScaffold sc = Eclipse.instance.moduleManager.getModule(WDScaffold.class);
        if (sc != null && sc.isEnabled()) sc.getSetting("Yaw Jitter").setValue(p.rotationJitter * 100);
    }
}
"""

WD_FINGERPRINT = r"""package me.eclipse.module.watchdog;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.RandomUtils;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

@ModuleInfo(name = "WDFingerprint", description = "2026 behavioral fingerprint avoidance", 
            category = Category.WATCHDOG, keyBind = 0)
public class WDFingerprint extends Module {
    private final SettingBoolean rhythmBreaker = new SettingBoolean("Rhythm Breaker", true);
    private final SettingDouble rhythmVariance = new SettingDouble("Rhythm Variance", 0.12, 0.0, 0.25, 0.01);
    private final SettingBoolean fingerprintRotation = new SettingBoolean("Rotation Fingerprint", true);
    private final SettingDouble rotFingerprintAmount = new SettingDouble("Rot Fingerprint", 0.4, 0.0, 1.0, 0.05);
    private final SettingBoolean longTermDrift = new SettingBoolean("Long-Term Drift", true);
    private final SettingDouble driftRate = new SettingDouble("Drift Rate", 0.001, 0.0, 0.01, 0.001);
    private final SettingBoolean sessionVariation = new SettingBoolean("Session Variation", true);
    
    private double sessionYawOffset;
    private double sessionTimingOffset;
    private long sessionStartTime;
    private long totalPlayTicks;
    private double yawDrift;
    private double timingDrift;
    private long[] actionTimestamps = new long[50];
    private int actionIndex;
    
    public WDFingerprint() {
        addSetting(rhythmBreaker, rhythmVariance, fingerprintRotation, rotFingerprintAmount,
                  longTermDrift, driftRate, sessionVariation);
    }
    
    @Override
    public void onEnable() {
        sessionYawOffset = RandomUtils.nextGaussian(0.5);
        sessionTimingOffset = RandomUtils.nextGaussian(20);
        sessionStartTime = System.currentTimeMillis();
        totalPlayTicks = 0;
        yawDrift = 0;
        timingDrift = 0;
        actionIndex = 0;
    }
    
    @EventHandler
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.thePlayer == null) return;
        totalPlayTicks++;
        
        if (sessionVariation.getValue()) {
            double playMinutes = (System.currentTimeMillis() - sessionStartTime) / 60000.0;
            double sessionFactor = Math.min(1.0, playMinutes / 30.0);
            if (totalPlayTicks % 100 == 0) {
                sessionYawOffset += RandomUtils.nextGaussian(0.01) * sessionFactor;
                sessionTimingOffset += RandomUtils.nextGaussian(0.5) * sessionFactor;
            }
        }
        
        if (longTermDrift.getValue()) {
            yawDrift += driftRate.getValue() * (Math.random() > 0.5 ? 1 : -1);
            if (Math.abs(yawDrift) > 2.0) yawDrift *= 0.5;
            timingDrift += driftRate.getValue() * 0.5 * (Math.random() > 0.5 ? 1 : -1);
        }
        
        if (rhythmBreaker.getValue()) {
            long now = System.currentTimeMillis();
            actionTimestamps[actionIndex % 50] = now;
            actionIndex++;
        }
    }
    
    public double getYawOffset() { return sessionYawOffset + yawDrift; }
    public double getTimingOffset() { return sessionTimingOffset + timingDrift; }
    public boolean shouldDelayAction() {
        if (!rhythmBreaker.getValue()) return false;
        return Math.random() < rhythmVariance.getValue() * 0.1;
    }
}
"""

WD_NOSLOW = r"""package me.eclipse.module.watchdog;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.RandomUtils;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

@ModuleInfo(name = "WDNoSlow", description = "Watchdog noslow bypass", 
            category = Category.WATCHDOG, keyBind = 0)
public class WDNoSlow extends Module {
    private final SettingDouble forwardMultiplier = new SettingDouble("Forward", 1.0, 0.5, 1.0, 0.05);
    private final SettingDouble strafeMultiplier = new SettingDouble("Strafe", 1.0, 0.5, 1.0, 0.05);
    private final SettingBoolean toggleMode = new SettingBoolean("Toggle Mode", true);
    private final SettingInteger onTicks = new SettingInteger("On Ticks", 3, 1, 10, 1);
    private final SettingInteger offTicks = new SettingInteger("Off Ticks", 1, 1, 5, 1);
    
    private int tickCounter;
    private boolean shouldBypass;
    
    public WDNoSlow() {
        addSetting(forwardMultiplier, strafeMultiplier, toggleMode, onTicks, offTicks);
    }
    
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (mc.thePlayer == null) return;
        if (!mc.thePlayer.isUsingItem() && !mc.thePlayer.isBlocking()) return;
        
        tickCounter++;
        
        if (toggleMode.getValue()) {
            int total = onTicks.getValue() + offTicks.getValue();
            shouldBypass = (tickCounter % total) < onTicks.getValue();
        } else {
            shouldBypass = true;
        }
        
        if (shouldBypass) {
            mc.thePlayer.movementInput.moveForward *= forwardMultiplier.getValue();
            mc.thePlayer.movementInput.moveStrafe *= strafeMultiplier.getValue();
        }
    }
}
"""

WD_MOVEMENT = r"""package me.eclipse.module.watchdog;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.RandomUtils;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

@ModuleInfo(name = "WDMovement", description = "Watchdog legit movement", 
            category = Category.WATCHDOG, keyBind = 0)
public class WDMovement extends Module {
    private final SettingBoolean wTapSim = new SettingBoolean("W-Tap Sim", true);
    private final SettingDouble wTapChance = new SettingDouble("W-Tap Chance", 0.3, 0.0, 0.8, 0.05);
    private final SettingBoolean microStutter = new SettingBoolean("Micro Stutter", true);
    private final SettingDouble stutterChance = new SettingDouble("Stutter Chance", 0.03, 0.0, 0.1, 0.01);
    private final SettingBoolean strafeVariance = new SettingBoolean("Strafe Variance", true);
    private final SettingDouble strafeJitter = new SettingDouble("Strafe Jitter", 0.5, 0.0, 2.0, 0.1);
    private final SettingBoolean jumpDelay = new SettingBoolean("Jump Delay", true);
    private final SettingInteger jumpDelayTicks = new SettingInteger("Jump Delay", 2, 0, 5, 1);
    
    private int wTapCooldown;
    private boolean isStuttering;
    private int stutterTicks;
    private int jumpDelayCounter;
    
    public WDMovement() {
        addSetting(wTapSim, wTapChance, microStutter, stutterChance, strafeVariance, strafeJitter, jumpDelay, jumpDelayTicks);
    }
    
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (mc.thePlayer == null) return;
        
        if (wTapSim.getValue() && mc.thePlayer.isMoving()) {
            if (wTapCooldown > 0) { wTapCooldown--; }
            else if (Math.random() < wTapChance.getValue() * 0.08) {
                mc.gameSettings.keyBindForward.pressed = false;
                wTapCooldown = RandomUtils.nextInt(1, 2);
                mc.gameSettings.keyBindForward.pressed = true;
            }
        }
        
        if (microStutter.getValue() && mc.thePlayer.isMoving() && !isStuttering) {
            if (Math.random() < stutterChance.getValue() * 0.04) {
                isStuttering = true;
                stutterTicks = RandomUtils.nextInt(1, 2);
            }
        }
        if (isStuttering) {
            mc.thePlayer.motionX *= 0.4;
            mc.thePlayer.motionZ *= 0.4;
            stutterTicks--;
            if (stutterTicks <= 0) isStuttering = false;
        }
        
        if (strafeVariance.getValue() && mc.thePlayer.movementInput.moveStrafe != 0) {
            mc.thePlayer.rotationYaw += (float) RandomUtils.nextGaussian(strafeJitter.getValue());
        }
    }
}
"""

SPEED_FULL = r"""package me.eclipse.module.movement;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.MathUtils;
import me.eclipse.utils.RandomUtils;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

@ModuleInfo(name = "Speed", description = "Moves faster", 
            category = Category.MOVEMENT, keyBind = 0x56)
public class Speed extends Module {
    private final SettingMode mode = new SettingMode("Mode", 
        new String[]{"Strafe", "LowHop", "OnGround", "Vanilla", "Packet", "BHop", "NCP", "AAC", "Matrix", "Hypixel"}, "Strafe");
    private final SettingDouble speed = new SettingDouble("Speed", 1.5, 0.5, 5.0, 0.1);
    private final SettingBoolean timerBoost = new SettingBoolean("Timer Boost", false);
    private final SettingDouble timerSpeed = new SettingDouble("Timer Speed", 1.08, 1.0, 1.5, 0.01);
    private final SettingBoolean vanillaJump = new SettingBoolean("Vanilla Jump", true);
    private final SettingBoolean strafe = new SettingBoolean("Strafe", true);
    private final SettingBoolean damageBoost = new SettingBoolean("Damage Boost", true);
    
    private int stage;
    private double moveSpeed;
    private boolean timerActive;
    
    public Speed() {
        addSetting(mode, speed, timerBoost, timerSpeed, vanillaJump, strafe, damageBoost);
    }
    
    @Override
    public void onEnable() { stage = 0; moveSpeed = getBaseSpeed(); timerActive = false; }
    
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (mc.thePlayer == null || !mc.thePlayer.isMoving()) {
            if (timerActive) { setTimer(1.0f); timerActive = false; }
            return;
        }
        if (mc.thePlayer.isInWater() || mc.thePlayer.isInLava()) return;
        
        if (damageBoost.getValue() && mc.thePlayer.hurtTime > 0) {
            mc.thePlayer.motionX *= 1.4;
            mc.thePlayer.motionZ *= 1.4;
        }
        
        switch (mode.getValue()) {
            case "Strafe": doStrafe(); break;
            case "LowHop": doLowHop(); break;
            case "OnGround": doOnGround(); break;
            case "Vanilla": doVanilla(); break;
            case "Packet": doPacket(); break;
            case "BHop": doBHop(); break;
            case "NCP": doNCP(); break;
            case "AAC": doAAC(); break;
            case "Matrix": doMatrix(); break;
            case "Hypixel": doHypixel(); break;
        }
    }
    
    private void doStrafe() {
        if (mc.thePlayer.onGround) {
            if (vanillaJump.getValue()) mc.thePlayer.motionY = 0.42;
            moveSpeed = getBaseSpeed() * speed.getValue();
            stage = 1;
        } else if (stage == 1) {
            moveSpeed = getBaseSpeed() * (speed.getValue() * 1.2);
            stage = 2;
        } else {
            moveSpeed = moveSpeed * 0.99;
            if (moveSpeed < getBaseSpeed()) moveSpeed = getBaseSpeed();
        }
        setMotion(moveSpeed);
        if (strafe.getValue()) doStrafeMove();
    }
    
    private void doLowHop() {
        double baseSpeed = getBaseSpeed() * speed.getValue();
        if (mc.thePlayer.onGround) mc.thePlayer.motionY = 0.12 + RandomUtils.nextGaussian(0.02);
        moveSpeed = Math.max(moveSpeed, baseSpeed * 0.9);
        setMotion(moveSpeed);
        if (strafe.getValue()) doStrafeMove();
    }
    
    private void doOnGround() {
        setMotion(getBaseSpeed() * speed.getValue() * 0.85);
        if (strafe.getValue()) doStrafeMove();
        if (timerBoost.getValue() && !timerActive) { setTimer(timerSpeed.getValue().floatValue()); timerActive = true; }
    }
    
    private void doVanilla() { mc.thePlayer.motionX *= speed.getValue(); mc.thePlayer.motionZ *= speed.getValue(); }
    
    private void doPacket() {
        if (mc.thePlayer.onGround) { mc.thePlayer.motionY = 0.42; moveSpeed = getBaseSpeed() * speed.getValue(); }
        double yaw = Math.toRadians(mc.thePlayer.rotationYaw);
        for (int i = 0; i < 3; i++) {
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(
                mc.thePlayer.posX - Math.sin(yaw) * 0.1 * i, mc.thePlayer.posY,
                mc.thePlayer.posZ + Math.cos(yaw) * 0.1 * i, mc.thePlayer.onGround));
        }
        setMotion(moveSpeed);
        if (strafe.getValue()) doStrafeMove();
    }
    
    private void doBHop() {
        if (mc.thePlayer.onGround) { mc.thePlayer.motionY = 0.42; moveSpeed = getBaseSpeed() * speed.getValue(); }
        moveSpeed *= 0.995;
        if (moveSpeed < getBaseSpeed()) moveSpeed = getBaseSpeed();
        setMotion(moveSpeed);
        if (strafe.getValue()) doStrafeMove();
    }
    
    private void doNCP() {
        if (mc.thePlayer.onGround) { mc.thePlayer.motionY = 0.42; moveSpeed = getBaseSpeed() * 1.5; stage = 1; }
        else if (stage == 1) { moveSpeed *= 0.81; stage = 2; }
        else { moveSpeed = moveSpeed - 0.66 * (moveSpeed - getBaseSpeed()); }
        setMotion(moveSpeed);
        if (strafe.getValue()) doStrafeMove();
    }
    
    private void doAAC() {
        if (mc.thePlayer.onGround) { mc.thePlayer.motionY = 0.42; moveSpeed = getBaseSpeed() * 2.15; }
        else { moveSpeed = getBaseSpeed(); }
        setMotion(moveSpeed);
        if (strafe.getValue()) doStrafeMove();
    }
    
    private void doMatrix() {
        double base = getBaseSpeed() * speed.getValue();
        if (mc.thePlayer.onGround) { mc.thePlayer.motionY = 0.42; moveSpeed = base; stage = 1; }
        else if (stage == 1) { moveSpeed = base * 1.3; stage = 2; }
        else { moveSpeed *= 0.98; }
        setMotion(Math.max(moveSpeed, base * 0.8));
        if (strafe.getValue()) doStrafeMove();
    }
    
    private void doHypixel() {
        double base = getBaseSpeed() * speed.getValue();
        if (mc.thePlayer.onGround) mc.thePlayer.motionY = 0.2 + RandomUtils.nextGaussian(0.03);
        if (!mc.thePlayer.onGround) {
            moveSpeed *= 0.985;
            if (mc.thePlayer.movementInput.moveStrafe != 0) moveSpeed *= 1.05;
        }
        setMotion(Math.max(moveSpeed, base * 0.85));
        if (strafe.getValue()) doStrafeMove();
    }
    
    private double getBaseSpeed() {
        double base = 0.2873;
        if (mc.thePlayer.isPotionActive(Potion.moveSpeed))
            base *= 1.0 + 0.2 * (mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1);
        return base;
    }
    
    private void setMotion(double speed) {
        double yaw = Math.toRadians(mc.thePlayer.rotationYaw);
        mc.thePlayer.motionX = -Math.sin(yaw) * speed;
        mc.thePlayer.motionZ = Math.cos(yaw) * speed;
    }
    
    private void doStrafeMove() {
        double yaw = Math.toRadians(mc.thePlayer.rotationYaw);
        double strafe = mc.thePlayer.movementInput.moveStrafe * 0.2873;
        mc.thePlayer.motionX += Math.cos(yaw) * strafe;
        mc.thePlayer.motionZ -= Math.sin(yaw) * strafe;
    }
    
    private void setTimer(float speed) {
        try {
            java.lang.reflect.Field f = Minecraft.class.getDeclaredField("timer");
            f.setAccessible(true);
            net.minecraft.util.Timer t = (net.minecraft.util.Timer) f.get(mc);
            t.timerSpeed = speed;
        } catch (Exception e) {}
    }
    
    @Override
    public void onDisable() { setTimer(1.0f); stage = 0; }
}
"""

FLY_FULL = r"""package me.eclipse.module.movement;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.RandomUtils;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

@ModuleInfo(name = "Fly", description = "Allows flight", 
            category = Category.MOVEMENT, keyBind = 0x47)
public class Fly extends Module {
    private final SettingMode mode = new SettingMode("Mode", 
        new String[]{"Vanilla", "Glide", "Packet", "Watchdog", "NCP", "AAC", "Matrix", "Spooky"}, "Vanilla");
    private final SettingDouble speed = new SettingDouble("Speed", 2.0, 0.5, 10.0, 0.1);
    private final SettingDouble verticalSpeed = new SettingDouble("Vertical", 1.0, 0.1, 5.0, 0.1);
    private final SettingBoolean antiKick = new SettingBoolean("Anti Kick", true);
    private final SettingInteger antiKickInterval = new SettingInteger("Kick Interval", 60, 20, 120, 5);
    
    private int antiKickCounter;
    private int packetCounter;
    
    public Fly() { addSetting(mode, speed, verticalSpeed, antiKick, antiKickInterval); }
    
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (mc.thePlayer == null) return;
        
        mc.thePlayer.capabilities.isFlying = false;
        mc.thePlayer.motionX = 0; mc.thePlayer.motionY = 0; mc.thePlayer.motionZ = 0;
        
        double forward = mc.thePlayer.movementInput.moveForward;
        double strafe = mc.thePlayer.movementInput.moveStrafe;
        float yaw = mc.thePlayer.rotationYaw;
        
        double moveX = -Math.sin(Math.toRadians(yaw)) * forward + Math.cos(Math.toRadians(yaw)) * strafe;
        double moveZ = Math.cos(Math.toRadians(yaw)) * forward + Math.sin(Math.toRadians(yaw)) * strafe;
        double len = Math.sqrt(moveX * moveX + moveZ * moveZ);
        if (len > 0) { moveX = (moveX / len) * speed.getValue() * 0.1; moveZ = (moveZ / len) * speed.getValue() * 0.1; }
        
        double moveY = 0;
        if (mc.thePlayer.movementInput.jump) moveY = verticalSpeed.getValue() * 0.1;
        if (mc.thePlayer.movementInput.sneak) moveY = -verticalSpeed.getValue() * 0.1;
        
        switch (mode.getValue()) {
            case "Vanilla":
                mc.thePlayer.motionX = moveX; mc.thePlayer.motionY = moveY; mc.thePlayer.motionZ = moveZ;
                break;
            case "Glide":
                mc.thePlayer.motionX = moveX; mc.thePlayer.motionZ = moveZ;
                mc.thePlayer.motionY = mc.thePlayer.movementInput.jump ? 0.5 : -0.05;
                break;
            case "Packet":
                mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(
                    mc.thePlayer.posX + moveX, mc.thePlayer.posY + moveY, mc.thePlayer.posZ + moveZ, false));
                break;
            case "Watchdog":
                packetCounter++;
                if (packetCounter % 3 == 0) { mc.thePlayer.motionX = moveX; mc.thePlayer.motionZ = moveZ; }
                mc.thePlayer.motionY = moveY * 0.5;
                break;
            case "NCP":
                mc.thePlayer.motionX = moveX; mc.thePlayer.motionZ = moveZ;
                if (packetCounter++ % 2 == 0)
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(
                        mc.thePlayer.posX, mc.thePlayer.posY - 0.05, mc.thePlayer.posZ, false));
                mc.thePlayer.motionY = moveY;
                break;
            case "AAC":
                if (mc.thePlayer.ticksExisted % 3 == 0) mc.thePlayer.motionY = 0.5;
                else mc.thePlayer.motionY = -0.5;
                mc.thePlayer.motionX = moveX * 0.5; mc.thePlayer.motionZ = moveZ * 0.5;
                break;
            case "Matrix":
                mc.thePlayer.motionX = moveX; mc.thePlayer.motionZ = moveZ;
                mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(
                    mc.thePlayer.posX, mc.thePlayer.posY + 0.05, mc.thePlayer.posZ, true));
                mc.thePlayer.motionY = moveY;
                break;
            case "Spooky":
                double t = mc.thePlayer.ticksExisted * 0.1;
                mc.thePlayer.motionX = moveX + Math.sin(t) * 0.1;
                mc.thePlayer.motionZ = moveZ + Math.cos(t) * 0.1;
                mc.thePlayer.motionY = moveY + Math.sin(t * 2) * 0.05;
                break;
        }
        
        if (antiKick.getValue() && mc.thePlayer.posY > 0) {
            antiKickCounter++;
            if (antiKickCounter >= antiKickInterval.getValue()) {
                mc.thePlayer.motionY = -0.1;
                mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
                antiKickCounter = 0;
            }
        }
    }
    
    @Override
    public void onDisable() {
        if (mc.thePlayer != null) { mc.thePlayer.motionX = 0; mc.thePlayer.motionY = 0; mc.thePlayer.motionZ = 0; }
        antiKickCounter = 0; packetCounter = 0;
    }
}
"""

KILL_AURA_FULL = r"""package me.eclipse.module.combat;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.*;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

import java.util.*;
import java.util.stream.Collectors;

@ModuleInfo(name = "KillAura", description = "Attacks nearby entities", 
            category = Category.COMBAT, keyBind = 0x52)
public class KillAura extends Module {
    private final SettingDouble range = new SettingDouble("Range", 3.8, 1.0, 6.0, 0.1);
    private final SettingDouble wallRange = new SettingDouble("Wall Range", 3.0, 0.0, 6.0, 0.1);
    private final SettingDouble fov = new SettingDouble("FOV", 180.0, 30.0, 360.0, 10.0);
    private final SettingMode targetMode = new SettingMode("Target", 
        new String[]{"Closest", "Health", "Angle", "Damage"}, "Closest");
    private final SettingInteger switchDelay = new SettingInteger("Switch Delay", 250, 0, 1000, 50);
    private final SettingBoolean multi = new SettingBoolean("Multi", false);
    private final SettingInteger multiTargets = new SettingInteger("Multi Targets", 2, 2, 5, 1);
    private final SettingMode rotationMode = new SettingMode("Rotation", 
        new String[]{"None", "Smooth", "Instant"}, "Smooth");
    private final SettingDouble rotationSpeed = new SettingDouble("Rot Speed", 90.0, 10.0, 180.0, 5.0);
    private final SettingBoolean silentAim = new SettingBoolean("Silent Aim", true);
    private final SettingBoolean criticals = new SettingBoolean("Criticals", true);
    private final SettingMode criticalsMode = new SettingMode("Crits Mode", 
        new String[]{"Jump", "Packet", "MiniJump"}, "Jump");
    private final SettingBoolean autoBlock = new SettingBoolean("Auto Block", false);
    private final SettingBoolean players = new SettingBoolean("Players", true);
    private final SettingBoolean mobs = new SettingBoolean("Mobs", false);
    private final SettingBoolean animals = new SettingBoolean("Animals", false);
    private final SettingBoolean invisibles = new SettingBoolean("Invisibles", false);
    
    private EntityLivingBase currentTarget;
    private List<EntityLivingBase> targets = new ArrayList<>();
    private long lastSwitchTime;
    private float[] serverRotations = new float[2];
    private boolean isBlocking;
    
    public KillAura() {
        addSetting(range, wallRange, fov, targetMode, switchDelay, multi, multiTargets,
                  rotationMode, rotationSpeed, silentAim, criticals, criticalsMode,
                  autoBlock, players, mobs, animals, invisibles);
    }
    
    @Override
    public void onEnable() {
        serverRotations[0] = mc.thePlayer.rotationYaw;
        serverRotations[1] = mc.thePlayer.rotationPitch;
    }
    
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (mc.thePlayer == null) return;
        
        targets = findTargets();
        if (targets.isEmpty()) { currentTarget = null; unblock(); return; }
        
        EntityLivingBase newTarget = targets.get(0);
        if (newTarget != currentTarget) {
            if (System.currentTimeMillis() - lastSwitchTime >= switchDelay.getValue()) {
                currentTarget = newTarget;
                lastSwitchTime = System.currentTimeMillis();
            }
        }
        if (currentTarget == null) return;
        
        float[] targetRots = getTargetRotations(currentTarget);
        if (rotationMode.getValue().equals("Smooth")) {
            float speed = (float) (rotationSpeed.getValue() * 0.017f);
            serverRotations[0] = lerpAngle(serverRotations[0], targetRots[0], speed);
            serverRotations[1] = lerpAngle(serverRotations[1], targetRots[1], speed);
        } else if (rotationMode.getValue().equals("Instant")) {
            serverRotations[0] = targetRots[0];
            serverRotations[1] = targetRots[1];
        }
        
        if (silentAim.getValue()) {
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(
                serverRotations[0], serverRotations[1], mc.thePlayer.onGround));
        } else {
            mc.thePlayer.rotationYaw = serverRotations[0];
            mc.thePlayer.rotationPitch = serverRotations[1];
        }
        
        if (mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword) unblock();
        doCriticals();
        attack(currentTarget);
        if (multi.getValue()) {
            for (int i = 1; i < Math.min(targets.size(), multiTargets.getValue()); i++) attack(targets.get(i));
        }
        if (autoBlock.getValue() && mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword) block();
    }
    
    private List<EntityLivingBase> findTargets() {
        List<EntityLivingBase> valid = new ArrayList<>();
        for (Entity entity : mc.theWorld.loadedEntityList) {
            if (!(entity instanceof EntityLivingBase) || entity == mc.thePlayer) continue;
            if (entity.isDead) continue;
            if (!invisibles.getValue() && entity.isInvisible()) continue;
            double dist = mc.thePlayer.getDistanceToEntity(entity);
            boolean canSee = mc.thePlayer.canEntityBeSeen(entity);
            if (dist > (canSee ? range.getValue() : wallRange.getValue())) continue;
            if (entity instanceof EntityPlayer && !players.getValue()) continue;
            if (EntityUtils.isMob(entity) && !mobs.getValue()) continue;
            if (EntityUtils.isAnimal(entity) && !animals.getValue()) continue;
            if (fov.getValue() < 360) {
                double angle = Math.abs(MathHelper.wrapAngleTo180_double(getRotations(entity)[0] - mc.thePlayer.rotationYaw));
                if (angle > fov.getValue() / 2) continue;
            }
            valid.add((EntityLivingBase) entity);
        }
        switch (targetMode.getValue()) {
            case "Closest": valid.sort(Comparator.comparingDouble(e -> mc.thePlayer.getDistanceToEntity(e))); break;
            case "Health": valid.sort(Comparator.comparingDouble(EntityLivingBase::getHealth)); break;
            case "Angle": valid.sort(Comparator.comparingDouble(e -> Math.abs(MathHelper.wrapAngleTo180_double(getRotations(e)[0] - mc.thePlayer.rotationYaw)))); break;
            case "Damage": valid.sort(Comparator.comparingDouble(EntityLivingBase::getTotalArmorValue)); break;
        }
        return valid;
    }
    
    private void doCriticals() {
        if (!criticals.getValue()) return;
        switch (criticalsMode.getValue()) {
            case "Jump": if (mc.thePlayer.onGround) { mc.thePlayer.motionY = 0.42; mc.thePlayer.fallDistance = 0.1f; } break;
            case "Packet": if (mc.thePlayer.onGround) {
                mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(false));
                mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(false));
                mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
            } break;
            case "MiniJump": if (mc.thePlayer.onGround) { mc.thePlayer.motionY = 0.1; mc.thePlayer.fallDistance = 0.1f; } break;
        }
    }
    
    private void attack(EntityLivingBase target) {
        mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(target, C02PacketUseEntity.Action.ATTACK));
        mc.thePlayer.attackTargetEntityWithCurrentItem(target);
        mc.thePlayer.swingItem();
    }
    
    private void block() {
        if (!isBlocking) { mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.getHeldItem())); isBlocking = true; }
    }
    private void unblock() {
        if (isBlocking) { mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN)); isBlocking = false; }
    }
    
    private float[] getTargetRotations(Entity entity) {
        double dx = entity.posX - mc.thePlayer.posX;
        double dy = (entity.posY + entity.getEyeHeight() * 0.8) - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = entity.posZ - mc.thePlayer.posZ;
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx*dx + dz*dz)));
        return new float[]{ MathHelper.wrapAngleTo180_float(yaw), MathHelper.clamp_float(pitch, -90f, 90f) };
    }
    
    private float[] getRotations(Entity entity) {
        double dx = entity.posX - mc.thePlayer.posX, dz = entity.posZ - mc.thePlayer.posZ;
        return new float[]{ MathHelper.wrapAngleTo180_float((float)Math.toDegrees(Math.atan2(dz, dx)) - 90f), 0f };
    }
    
    private float lerpAngle(float from, float to, float speed) {
        float diff = MathHelper.wrapAngleTo180_float(to - from);
        return Math.abs(diff) < speed ? to : from + (diff > 0 ? speed : -speed);
    }
    
    @Override
    public void onDisable() { currentTarget = null; targets.clear(); unblock(); }
}
"""

VELOCITY_FULL = r"""package me.eclipse.module.combat;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.RandomUtils;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

@ModuleInfo(name = "Velocity", description = "Reduces knockback", 
            category = Category.COMBAT, keyBind = 0)
public class Velocity extends Module {
    private final SettingMode mode = new SettingMode("Mode", 
        new String[]{"Cancel", "Reduce", "Reverse", "Jump", "Packet"}, "Reduce");
    private final SettingDouble horizontal = new SettingDouble("Horizontal", 0.0, 0.0, 100.0, 5.0);
    private final SettingDouble vertical = new SettingDouble("Vertical", 0.0, 0.0, 100.0, 5.0);
    private final SettingBoolean groundOnly = new SettingBoolean("Ground Only", false);
    private final SettingBoolean hurtOnly = new SettingBoolean("Hurt Only", true);
    
    public Velocity() { addSetting(mode, horizontal, vertical, groundOnly, hurtOnly); }
    
    @EventHandler
    public void onVelocity(PacketEvent.Receive event) {
        if (!(event.getPacket() instanceof S12PacketEntityVelocity)) return;
        S12PacketEntityVelocity packet = (S12PacketEntityVelocity) event.getPacket();
        if (packet.getEntityID() != mc.thePlayer.getEntityId()) return;
        if (groundOnly.getValue() && !mc.thePlayer.onGround) return;
        if (hurtOnly.getValue() && mc.thePlayer.hurtTime == 0) return;
        
        double h = horizontal.getValue() / 100.0, v = vertical.getValue() / 100.0;
        switch (mode.getValue()) {
            case "Cancel": event.setCancelled(true); break;
            case "Reduce":
                mc.thePlayer.motionX = packet.getMotionX() / 8000.0 * h;
                mc.thePlayer.motionY = packet.getMotionY() / 8000.0 * v;
                mc.thePlayer.motionZ = packet.getMotionZ() / 8000.0 * h;
                event.setCancelled(true); break;
            case "Reverse":
                mc.thePlayer.motionX = -(packet.getMotionX() / 8000.0 * h);
                mc.thePlayer.motionZ = -(packet.getMotionZ() / 8000.0 * h);
                mc.thePlayer.motionY = packet.getMotionY() / 8000.0 * v;
                event.setCancelled(true); break;
            case "Jump":
                if (mc.thePlayer.onGround) mc.thePlayer.motionY = 0.42;
                mc.thePlayer.motionX *= h; mc.thePlayer.motionZ *= h;
                event.setCancelled(true); break;
            case "Packet":
                mc.thePlayer.motionX *= h; mc.thePlayer.motionZ *= h; break;
        }
    }
}
"""

SCAFFOLD_FULL = r"""package me.eclipse.module.player;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.ModuleInfo;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import me.eclipse.utils.*;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.*;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

@ModuleInfo(name = "Scaffold", description = "Places blocks under you", 
            category = Category.PLAYER, keyBind = 0x42)
public class Scaffold extends Module {
    private final SettingDouble expand = new SettingDouble("Expand", 0.0, 0.0, 6.0, 0.1);
    private final SettingBoolean tower = new SettingBoolean("Tower", false);
    private final SettingDouble towerSpeed = new SettingDouble("Tower Speed", 1.0, 0.5, 2.0, 0.1);
    private final SettingMode rotationMode = new SettingMode("Rotation", 
        new String[]{"None", "Normal", "Smooth", "Backwards"}, "Normal");
    private final SettingDouble rotationSpeed = new SettingDouble("Rot Speed", 50.0, 10.0, 180.0, 5.0);
    private final SettingBoolean eagle = new SettingBoolean("Eagle", true);
    private final SettingBoolean keepY = new SettingBoolean("Keep Y", true);
    private final SettingInteger delay = new SettingInteger("Delay", 0, 0, 100, 5);
    private final SettingBoolean swing = new SettingBoolean("Swing", true);
    private final SettingBoolean silentSwitch = new SettingBoolean("Silent Switch", true);
    
    private long lastPlaceTime;
    private int blockSlot;
    private float[] serverRotations = new float[2];
    private boolean shouldSneak;
    private double startY;
    
    public Scaffold() {
        addSetting(expand, tower, towerSpeed, rotationMode, rotationSpeed, eagle, keepY, delay, swing, silentSwitch);
    }
    
    @Override
    public void onEnable() {
        blockSlot = findBlockSlot(); startY = mc.thePlayer.posY;
        serverRotations[0] = mc.thePlayer.rotationYaw; serverRotations[1] = mc.thePlayer.rotationPitch;
    }
    
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (mc.thePlayer == null) return;
        blockSlot = findBlockSlot();
        if (blockSlot == -1) return;
        if (keepY.getValue() && mc.thePlayer.onGround) { mc.thePlayer.posY = startY; mc.thePlayer.setPosition(mc.thePlayer.posX, startY, mc.thePlayer.posZ); }
        double[] pos = getTargetPosition();
        BlockPos target = new BlockPos(Math.floor(pos[0]), Math.floor(pos[1]) - 1, Math.floor(pos[2]));
        if (mc.theWorld.getBlockState(target).getBlock().isFullBlock()) return;
        if (eagle.getValue()) {
            boolean shouldEagle = !mc.theWorld.getBlockState(new BlockPos(Math.floor(mc.thePlayer.posX), Math.floor(mc.thePlayer.posY) - 1, Math.floor(mc.thePlayer.posZ))).getBlock().isFullBlock();
            mc.gameSettings.keyBindSneak.pressed = shouldEagle; shouldSneak = shouldEagle;
        }
        if (delay.getValue() > 0 && System.currentTimeMillis() - lastPlaceTime < delay.getValue()) return;
        PlaceResult place = getPlacePosition(target);
        if (place == null) return;
        float[] rotations = calculateRotations(place.pos);
        switch (rotationMode.getValue()) {
            case "Normal": mc.thePlayer.rotationYaw = rotations[0]; mc.thePlayer.rotationPitch = rotations[1]; break;
            case "Smooth":
                float speed = (float) (rotationSpeed.getValue() * 0.017f);
                serverRotations[0] = lerpAngle(serverRotations[0], rotations[0], speed);
                serverRotations[1] = lerpAngle(serverRotations[1], rotations[1], speed);
                mc.thePlayer.rotationYaw = serverRotations[0]; mc.thePlayer.rotationPitch = serverRotations[1]; break;
            case "Backwards": mc.thePlayer.rotationYaw = rotations[0] + 180; mc.thePlayer.rotationPitch = rotations[1]; break;
        }
        if (mc.thePlayer.inventory.currentItem != blockSlot) {
            if (silentSwitch.getValue()) mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(blockSlot));
            else mc.thePlayer.inventory.currentItem = blockSlot;
        }
        mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem(), place.pos, place.face, new Vec3(place.pos).addVector(0.5, 0.5, 0.5));
        if (swing.getValue()) mc.thePlayer.swingItem();
        if (silentSwitch.getValue()) mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
        lastPlaceTime = System.currentTimeMillis();
        if (tower.getValue() && mc.gameSettings.keyBindJump.isKeyDown() && mc.thePlayer.onGround) {
            mc.thePlayer.motionY = 0.42 * towerSpeed.getValue(); startY = mc.thePlayer.posY;
        }
    }
    
    private double[] getTargetPosition() {
        if (expand.getValue() == 0) return new double[]{mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ};
        double yaw = Math.toRadians(mc.thePlayer.rotationYaw + 90);
        return new double[]{mc.thePlayer.posX + Math.cos(yaw) * expand.getValue(), mc.thePlayer.posY, mc.thePlayer.posZ + Math.sin(yaw) * expand.getValue()};
    }
    
    private PlaceResult getPlacePosition(BlockPos target) {
        for (EnumFacing face : EnumFacing.values()) {
            if (face == EnumFacing.UP) continue;
            BlockPos adj = target.offset(face);
            Block block = mc.theWorld.getBlockState(adj).getBlock();
            if (!block.isAir(mc.theWorld, adj) && block != Blocks.water && block != Blocks.lava) return new PlaceResult(adj, face.getOpposite());
        }
        return null;
    }
    
    private float[] calculateRotations(BlockPos pos) {
        double x = pos.getX() + 0.5 - mc.thePlayer.posX, y = pos.getY() + 0.5 - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight()), z = pos.getZ() + 0.5 - mc.thePlayer.posZ;
        float yaw = (float) Math.toDegrees(Math.atan2(z, x)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(y, Math.sqrt(x*x + z*z)));
        return new float[]{ MathHelper.wrapAngleTo180_float(yaw), MathHelper.clamp_float(pitch, -90f, 90f) };
    }
    
    private int findBlockSlot() { for (int i = 0; i < 9; i++) { ItemStack s = mc.thePlayer.inventory.mainInventory[i]; if (s != null && s.getItem() instanceof ItemBlock) return i; } return -1; }
    private float lerpAngle(float from, float to, float speed) { float diff = MathHelper.wrapAngleTo180_float(to - from); return Math.abs(diff) < speed ? to : from + (diff > 0 ? speed : -speed); }
    
    @Override
    public void onDisable() { if (shouldSneak) mc.gameSettings.keyBindSneak.pressed = false; }
    
    private class PlaceResult { final BlockPos pos; final EnumFacing face; PlaceResult(BlockPos p, EnumFacing f) { pos = p; face = f; } }
}
"""

# ═══════════════════════════════════════════════════════════════
# MIXIN IMPLEMENTATIONS
# ═══════════════════════════════════════════════════════════════

MIXIN_ENTITY_PLAYER = r"""package me.eclipse.mixin;

import me.eclipse.Eclipse;
import me.eclipse.module.movement.*;
import me.eclipse.module.player.Scaffold;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.MovementInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityPlayerSP.class)
public class MixinEntityPlayerSP {
    @Shadow public MovementInput movementInput;
    @Shadow protected net.minecraft.client.Minecraft mc;
    
    @Inject(method = "onLivingUpdate", at = @At("HEAD"))
    private void onLivingUpdateHead(CallbackInfo ci) {
        NoSlow noSlow = Eclipse.instance.moduleManager.getModule(NoSlow.class);
        if (noSlow != null && noSlow.isEnabled()) {
            EntityPlayerSP self = (EntityPlayerSP) (Object) this;
            if (self.isUsingItem() || self.isBlocking()) {
                self.movementInput.moveForward *= 1.0;
                self.movementInput.moveStrafe *= 1.0;
            }
        }
    }
    
    @Redirect(method = "setSprinting", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/EntityPlayerSP;isOnGround()Z", ordinal = 3))
    private boolean isOnGroundRedirect(EntityPlayerSP self) {
        AirJump airJump = Eclipse.instance.moduleManager.getModule(AirJump.class);
        if (airJump != null && airJump.isEnabled()) return true;
        return self.isOnGround();
    }
}
"""

MIXIN_PLAYER_CONTROLLER = r"""package me.eclipse.mixin;

import me.eclipse.Eclipse;
import me.eclipse.module.combat.Reach;
import me.eclipse.module.player.Scaffold;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerControllerMP.class)
public class MixinPlayerControllerMP {
    
    @Inject(method = "getReachDistance", at = @At("RETURN"), cancellable = true)
    private void getReachDistance(CallbackInfoReturnable<Float> cir) {
        Reach reach = Eclipse.instance.moduleManager.getModule(Reach.class);
        if (reach != null && reach.isEnabled()) cir.setReturnValue(4.5f);
    }
    
    @Inject(method = "getBlockReachDistance", at = @At("RETURN"), cancellable = true)
    private void getBlockReachDistance(CallbackInfoReturnable<Float> cir) {
        Reach reach = Eclipse.instance.moduleManager.getModule(Reach.class);
        if (reach != null && reach.isEnabled()) cir.setReturnValue(5.0f);
    }
    
    @ModifyConstant(method = "onPlayerRightClick", constant = @Constant(longValue = 250L))
    private long removeClickDelay(long original) {
        Scaffold scaffold = Eclipse.instance.moduleManager.getModule(Scaffold.class);
        if (scaffold != null && scaffold.isEnabled()) return 0L;
        return original;
    }
}
"""

MIXIN_NET_HANDLER = r"""package me.eclipse.mixin;

import me.eclipse.Eclipse;
import me.eclipse.network.PacketEvent;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(NetHandlerPlayClient.class)
public class MixinNetHandlerPlayClient {
    
    @Inject(method = "handleEntityVelocity", at = @At("HEAD"), cancellable = true)
    private void handleVelocity(S12PacketEntityVelocity packet, CallbackInfo ci) {
        PacketEvent.Receive event = new PacketEvent.Receive(packet);
        Eclipse.instance.eventBus.post(event);
        if (event.isCancelled()) ci.cancel();
    }
    
    @Inject(method = "handlePlayerPosLook", at = @At("HEAD"), cancellable = true)
    private void handlePosLook(S08PacketPlayerPosLook packet, CallbackInfo ci) {
        PacketEvent.Receive event = new PacketEvent.Receive(packet);
        Eclipse.instance.eventBus.post(event);
        if (event.isCancelled()) ci.cancel();
    }
}
"""

MIXIN_NETWORK_MANAGER = r"""package me.eclipse.mixin;

import me.eclipse.Eclipse;
import me.eclipse.network.PacketEvent;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(NetworkManager.class)
public class MixinNetworkManager {
    
    @Inject(method = "sendPacket(Lnet/minecraft/network/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void sendPacket(Packet<?> packet, CallbackInfo ci) {
        if (Eclipse.instance == null) return;
        PacketEvent.Send event = new PacketEvent.Send(packet);
        Eclipse.instance.eventBus.post(event);
        if (event.isCancelled()) ci.cancel();
    }
}
"""

MIXIN_RENDERER_LIVING = r"""package me.eclipse.mixin;

import me.eclipse.Eclipse;
import me.eclipse.module.render.*;
import net.minecraft.entity.EntityLivingBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(net.minecraft.client.renderer.entity.RendererLivingEntity.class)
public class MixinRendererLivingEntity {
    
    @Inject(method = "renderName", at = @At("HEAD"), cancellable = true)
    private void renderName(EntityLivingBase entity, double x, double y, double z, CallbackInfo ci) {
        NameTags nameTags = Eclipse.instance.moduleManager.getModule(NameTags.class);
        if (nameTags != null && nameTags.isEnabled()) ci.cancel();
        NameProtect nameProtect = Eclipse.instance.moduleManager.getModule(NameProtect.class);
        if (nameProtect != null && nameProtect.isEnabled()) ci.cancel();
    }
}
"""

MIXIN_GUI_INGAME = r"""package me.eclipse.mixin;

import me.eclipse.Eclipse;
import me.eclipse.module.render.NoRender;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(net.minecraft.client.gui.GuiIngame.class)
public class MixinGuiIngame {
    
    @Inject(method = "renderBossHealth", at = @At("HEAD"), cancellable = true)
    private void renderBossHealth(CallbackInfo ci) {
        NoRender noRender = Eclipse.instance.moduleManager.getModule(NoRender.class);
        if (noRender != null && noRender.isEnabled()) ci.cancel();
    }
    
    @Inject(method = "renderPotionEffects", at = @At("HEAD"), cancellable = true)
    private void renderPotionEffects(CallbackInfo ci) {
        NoRender noRender = Eclipse.instance.moduleManager.getModule(NoRender.class);
        if (noRender != null && noRender.isEnabled()) ci.cancel();
    }
}
"""

# ═══════════════════════════════════════════════════════════════
# IMPLEMENTATION MAP
# ═══════════════════════════════════════════════════════════════

IMPLEMENTATIONS = {
    "watchdog/WDSpeed.java": WD_SPEED,
    "watchdog/WDScaffold.java": WD_SCAFFOLD,
    "watchdog/WDKillAura.java": WD_KILL_AURA,
    "watchdog/WDVelocity.java": WD_VELOCITY,
    "watchdog/WDTimer.java": WD_TIMER,
    "watchdog/WDProfile.java": WD_PROFILE,
    "watchdog/WDFingerprint.java": WD_FINGERPRINT,
    "watchdog/WDNoSlow.java": WD_NOSLOW,
    "watchdog/WDMovement.java": WD_MOVEMENT,
    "movement/Speed.java": SPEED_FULL,
    "movement/Fly.java": FLY_FULL,
    "combat/KillAura.java": KILL_AURA_FULL,
    "combat/Velocity.java": VELOCITY_FULL,
    "player/Scaffold.java": SCAFFOLD_FULL,
    "mixin/MixinEntityPlayerSP.java": MIXIN_ENTITY_PLAYER,
    "mixin/MixinPlayerControllerMP.java": MIXIN_PLAYER_CONTROLLER,
    "mixin/MixinNetHandlerPlayClient.java": MIXIN_NET_HANDLER,
    "mixin/MixinNetworkManager.java": MIXIN_NETWORK_MANAGER,
    "mixin/MixinRendererLivingEntity.java": MIXIN_RENDERER_LIVING,
    "mixin/MixinGuiIngame.java": MIXIN_GUI_INGAME,
}

def main():
    parser = argparse.ArgumentParser(description="Eclipse Implementation Injector")
    parser.add_argument("--source", "-s", default="./EclipseClient", help="Project directory")
    parser.add_argument("--dry", "-d", action="store_true", help="Dry run - show what would be done")
    args = parser.parse_args()
    
    src = Path(args.source)
    
    print(f"\n  {B}Eclipse Implementation Injector{X}")
    print(f"  {D}Source: {args.source}{X}\n")
    
    if not src.exists():
        err(f"Directory not found: {args.source}")
        sys.exit(1)
    
    count = 0
    for rel_path, content in IMPLEMENTATIONS.items():
        full_path = src / "src/main/java/me/eclipse/module" / rel_path
        if not full_path.exists():
            full_path = src / "src/main/java/me/eclipse" / rel_path
        
        if not full_path.exists():
            err(f"Not found: {rel_path}")
            continue
        
        if args.dry:
            info(f"Would update: {rel_path}")
            count += 1
        else:
            try:
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(content)
                ok(f"Updated: {rel_path}")
                count += 1
            except Exception as e:
                err(f"Failed: {rel_path} - {e}")
    
    print(f"\n  {G}+{X} {count} files updated\n")

if __name__ == "__main__":
    main()