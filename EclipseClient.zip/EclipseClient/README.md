# Eclipse Client v2.0.0

## Minecraft 1.8.9 Hacked Client
### Forge Mod + Injector Hybrid

## Building
1. Run `gradle wrapper` to generate wrapper files
2. Run `gradlew setupDecompWorkspace`
3. Run `gradlew build`
4. Find JAR in `build/libs/`

## Commands
- `.toggle <module>` - Toggle module
- `.help` - Show commands
- `.watchdog profile <name>` - Set WD profile

## Injector
See `eclipse-injector/` for C++ injector source.
