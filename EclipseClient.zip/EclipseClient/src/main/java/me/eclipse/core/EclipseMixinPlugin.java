package me.eclipse.core;

import org.spongepowered.asm.launch.MixinBootstrap;
import org.spongepowered.asm.mixin.MixinEnvironment;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
import java.util.Map;

public class EclipseMixinPlugin implements IFMLLoadingPlugin {
    public EclipseMixinPlugin() {
        MixinBootstrap.init();
        MixinEnvironment.getDefaultEnvironment().setObfuscationContext("searge");
    }
    public String[] getASMTransformerClass() { return new String[0]; }
    public String getModContainerClass() { return null; }
    public String getSetupClass() { return null; }
    public void injectData(Map<String, Object> data) {}
    public String getAccessTransformerClass() { return null; }
}
