package me.eclipse.core;
public interface Cancellable {
    boolean isCancelled();
    void setCancelled(boolean cancelled);
}
