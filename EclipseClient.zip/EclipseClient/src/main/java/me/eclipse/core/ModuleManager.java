package me.eclipse.core;

import me.eclipse.module.Module;
import me.eclipse.module.combat.*;
import me.eclipse.module.movement.*;
import me.eclipse.module.player.*;
import me.eclipse.module.render.*;
import me.eclipse.module.watchdog.*;
import me.eclipse.module.misc.*;
import me.eclipse.module.enums.Category;
import java.util.*;
import java.util.stream.Collectors;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    
    public ModuleManager() {
        register(new KillAura(), new Velocity(), new Criticals(), new AutoClicker(),
                 new Reach(), new CPSLimit(), new BowAimbot(), new AutoPot(),
                 new AutoSoup(), new AutoHeal(), new AntiBot(), new Backtrack(), new TargetStrafe());
        register(new Speed(), new Fly(), new LongJump(), new NoSlow(), new Strafe(),
                 new Spider(), new Step(), new HighJump(), new LiquidWalk(), new Jesus(),
                 new SafeWalk(), new AirJump(), new Timer());
        register(new Scaffold(), new Tower(), new AutoArmor(), new ChestStealer(),
                 new InvManager(), new AutoTool(), new AutoFish(), new AutoGG(),
                 new AutoPlay(), new AntiVoid(), new Blink(), new Phase(), new Disabler(), new Freecam());
        register(new ClickGUI(), new HUD(), new ArrayListMod(), new Keystrokes(),
                 new CPSCounter(), new TargetHUD(), new NameTags(), new Tracers(),
                 new Radar(), new BlockOverlay(), new Breadcrumbs(), new JumpCircle(),
                 new ChinaHat(), new StorageESP(), new ItemESP(), new ProjectileESP(),
                 new Chams(), new ESP(), new Trajectories(), new Fullbright(),
                 new Xray(), new ItemPhysics(), new Animations(), new NoRender());
        register(new WDSpeed(), new WDScaffold(), new WDKillAura(), new WDMovement(),
                 new WDNoSlow(), new WDVelocity(), new WDTimer(), new WDDisabler(),
                 new WDMacro(), new WDProfile(), new WDFingerprint());
        register(new Spammer(), new MidClick(), new AutoRespawn(), new SkinFlicker(),
                 new NameProtect(), new LootFilter(), new PearlPhaser(), new AntiHunger(),
                 new PortalMenu(), new NoRotateSet(), new PacketLimiter(), new SessionInfo());
    }
    
    private void register(Module... ms) { modules.addAll(Arrays.asList(ms)); }
    public Module getModule(String n) { return modules.stream().filter(m -> m.getName().equalsIgnoreCase(n)).findFirst().orElse(null); }
    public <T extends Module> T getModule(Class<T> c) { return modules.stream().filter(m -> m.getClass() == c).map(m -> (T)m).findFirst().orElse(null); }
    public List<Module> getModulesInCategory(Category c) { return modules.stream().filter(m -> m.getCategory() == c).collect(Collectors.toList()); }
    public List<Module> getEnabledModules() { return modules.stream().filter(Module::isEnabled).collect(Collectors.toList()); }
    public List<Module> getModules() { return modules; }
}
