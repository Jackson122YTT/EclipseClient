package me.eclipse.core;

import me.eclipse.Eclipse;
import me.eclipse.utils.Logger;
import java.io.File;

public class ConfigManager {
    private final File dir;
    public ConfigManager() { dir = new File(Eclipse.instance.mc.mcDataDir, "eclipse"); if(!dir.exists()) dir.mkdirs(); }
    public void saveConfig(String name) { Logger.log("Config saved: " + name); }
    public void loadConfig(String name) { Logger.log("Config loaded: " + name); }
    public void loadConfigs() {}
}
