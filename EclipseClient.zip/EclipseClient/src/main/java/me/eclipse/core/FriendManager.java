package me.eclipse.core;
import java.util.HashSet;
import java.util.Set;
public class FriendManager {
    private final Set<String> friends = new HashSet<>();
    public boolean isFriend(String n) { return friends.contains(n.toLowerCase()); }
    public void addFriend(String n) { friends.add(n.toLowerCase()); }
    public void removeFriend(String n) { friends.remove(n.toLowerCase()); }
    public Set<String> getFriends() { return friends; }
}
