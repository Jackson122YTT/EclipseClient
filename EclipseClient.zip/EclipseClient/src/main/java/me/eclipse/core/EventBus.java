package me.eclipse.core;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventBus {
    private final Map<Class<?>, CopyOnWriteArrayList<EventListener>> listeners = new ConcurrentHashMap<>();
    
    public void register(Object obj) {
        for (Method m : obj.getClass().getDeclaredMethods()) {
            if (m.isAnnotationPresent(EventHandler.class) && m.getParameterCount() == 1) {
                m.setAccessible(true);
                Class<?> cls = m.getParameterTypes()[0];
                listeners.computeIfAbsent(cls, k -> new CopyOnWriteArrayList<>())
                    .add(new EventListener(obj, m, m.getAnnotation(EventHandler.class).priority()));
                listeners.get(cls).sort(Comparator.comparingInt(e -> e.priority));
            }
        }
    }
    
    public void unregister(Object obj) {
        listeners.values().forEach(l -> l.removeIf(e -> e.obj == obj));
    }
    
    @SuppressWarnings("unchecked")
    public <T> T post(T event) {
        CopyOnWriteArrayList<EventListener> list = listeners.get(event.getClass());
        if (list != null) {
            for (EventListener el : list) {
                try { el.method.invoke(el.obj, event); }
                catch (Exception e) { e.printStackTrace(); }
                if (event instanceof Cancellable && ((Cancellable) event).isCancelled()) break;
            }
        }
        return event;
    }
    
    private static class EventListener {
        final Object obj; final Method method; final int priority;
        EventListener(Object o, Method m, int p) { obj = o; method = m; priority = p; }
    }
}
