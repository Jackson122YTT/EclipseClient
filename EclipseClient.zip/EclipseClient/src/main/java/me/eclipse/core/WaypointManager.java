package me.eclipse.core;
import java.util.ArrayList;
import java.util.List;
public class WaypointManager {
    public static class Waypoint { public String name; public double x,y,z; public int color; }
    private final List<Waypoint> wps = new ArrayList<>();
    public void addWaypoint(Waypoint w) { wps.add(w); }
    public void removeWaypoint(Waypoint w) { wps.remove(w); }
    public List<Waypoint> getWaypoints() { return wps; }
}
