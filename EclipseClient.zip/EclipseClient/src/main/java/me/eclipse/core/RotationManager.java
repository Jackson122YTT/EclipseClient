package me.eclipse.core;

import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.client.Minecraft;

public class RotationManager {
    private float serverYaw, serverPitch;
    private static final Minecraft mc = Minecraft.getMinecraft();
    
    public RotationPair getRotations(Entity target, float height, float yStep, float pStep) {
        double dx = target.posX - mc.thePlayer.posX;
        double dy = (target.posY + target.getEyeHeight() * height) - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz = target.posZ - mc.thePlayer.posZ;
        float yaw = MathHelper.wrapAngleTo180_float((float)Math.toDegrees(Math.atan2(dz, dx)) - 90f);
        float pitch = MathHelper.clamp_float((float)-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx*dx + dz*dz))), -90f, 90f);
        return new RotationPair(lerp(serverYaw, yaw, yStep), lerp(serverPitch, pitch, pStep));
    }
    
    private float lerp(float from, float to, float speed) {
        float d = MathHelper.wrapAngleTo180_float(to - from);
        return Math.abs(d) < speed ? to : from + (d > 0 ? speed : -speed);
    }
    
    public void updateServerRotations(float y, float p) { serverYaw = y; serverPitch = p; }
    public float getServerYaw() { return serverYaw; }
    public float getServerPitch() { return serverPitch; }
    
    public static class RotationPair { public final float yaw, pitch; public RotationPair(float y, float p) { yaw = y; pitch = p; } }
}
