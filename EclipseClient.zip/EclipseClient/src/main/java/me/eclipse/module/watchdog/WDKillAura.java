package me.eclipse.module.watchdog;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

public class WDKillAura extends Module {
    public WDKillAura() {
        super("WDKillAura", "WD combat", Category.WATCHDOG, 0);
    }
    @Override public void onEnable() { super.onEnable(); }
    @Override public void onDisable() { super.onDisable(); }
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent e) {
        if(e.phase != TickEvent.Phase.START) return;
        // TODO: Implement WDKillAura
    }
}
