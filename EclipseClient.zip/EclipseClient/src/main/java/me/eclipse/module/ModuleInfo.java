package me.eclipse.module;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface ModuleInfo {
    String name(); String description(); me.eclipse.module.enums.Category category(); int keyBind();
}
