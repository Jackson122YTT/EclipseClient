package me.eclipse.module.setting;
import java.awt.Color;
public class SettingColor extends Setting {
    private Color color;
    public SettingColor(String n, Color c) { super(n); color = c; }
    public SettingColor(String n, int r, int g, int b, int a) { super(n); color = new Color(r, g, b, a); }
    public Color getColor() { return color; }
    public void setColor(Color c) { color = c; }
    public double getMin() { return 0; }
    public double getMax() { return 255; }
    public double getIncrement() { return 1; }
}
