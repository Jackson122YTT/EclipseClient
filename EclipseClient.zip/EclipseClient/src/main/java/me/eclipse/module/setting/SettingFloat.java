package me.eclipse.module.setting;
public class SettingFloat extends Setting {
    private float value, min, max, inc;
    public SettingFloat(String n, float v, float mn, float mx, float i) { super(n); value=v; min=mn; max=mx; inc=i; }
    public float getValue() { return value; }
    public void setValue(float v) { value = v; }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getIncrement() { return inc; }
}
