package me.eclipse.module.misc;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

public class AutoRespawn extends Module {
    public AutoRespawn() {
        super("AutoRespawn", "Auto respawn", Category.MISC, 0);
    }
    @Override public void onEnable() { super.onEnable(); }
    @Override public void onDisable() { super.onDisable(); }
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent e) {
        if(e.phase != TickEvent.Phase.START) return;
        // TODO: Implement AutoRespawn
    }
}
