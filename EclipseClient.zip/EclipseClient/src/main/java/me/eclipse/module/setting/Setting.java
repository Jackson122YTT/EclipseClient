package me.eclipse.module.setting;
public abstract class Setting {
    private final String name;
    public Setting(String n) { name = n; }
    public String getName() { return name; }
    public abstract double getMin();
    public abstract double getMax();
    public abstract double getIncrement();
}
