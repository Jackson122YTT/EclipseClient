package me.eclipse.module.enums;

public enum Category {
    COMBAT("Combat", 0xFFE74C3C),
    MOVEMENT("Movement", 0xFF3498DB),
    PLAYER("Player", 0xFF2ECC71),
    RENDER("Render", 0xFF9B59B6),
    WATCHDOG("Watchdog", 0xFFF39C12),
    MISC("Misc", 0xFF1ABC9C);
    
    private final String name; private final int color;
    Category(String n, int c) { name = n; color = c; }
    public String getName() { return name; }
    public int getColor() { return color; }
    public String getIcon() {
        switch(this) {
            case COMBAT: return "S"; case MOVEMENT: return "D"; case PLAYER: return "E";
            case RENDER: return "G"; case WATCHDOG: return "W"; case MISC: return "F";
            default: return "?";
        }
    }
}
