package me.eclipse.module.setting;
public class SettingInteger extends Setting {
    private int value, min, max, inc;
    public SettingInteger(String n, int v, int mn, int mx, int i) { super(n); value=v; min=mn; max=mx; inc=i; }
    public int getValue() { return value; }
    public void setValue(int v) { value = v; }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getIncrement() { return inc; }
}
