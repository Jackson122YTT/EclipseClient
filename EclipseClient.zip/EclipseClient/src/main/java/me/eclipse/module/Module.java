package me.eclipse.module;

import me.eclipse.Eclipse;
import me.eclipse.core.EventBus;
import me.eclipse.module.setting.Setting;
import net.minecraft.client.Minecraft;
import java.util.ArrayList;
import java.util.List;

public class Module {
    protected final Minecraft mc = Minecraft.getMinecraft();
    protected static final EventBus eventBus = Eclipse.instance.eventBus;
    private final String name, description;
    private final Category category;
    private final int keyBind;
    private boolean enabled, hidden;
    private final List<Setting> settings = new ArrayList<>();
    private float slide, targetSlide;
    
    public Module(String name, String desc, Category cat, int key) {
        this.name = name; this.description = desc; this.category = cat; this.keyBind = key;
    }
    
    public void onEnable() {}
    public void onDisable() {}
    public void onToggle() {}
    
    public void enable() {
        enabled = true; targetSlide = 1f; eventBus.register(this); onEnable(); onToggle();
    }
    public void disable() {
        enabled = false; targetSlide = 0f; eventBus.unregister(this); onDisable(); onToggle();
    }
    public void toggle() { if (enabled) disable(); else enable(); }
    public void addSetting(Setting s) { settings.add(s); }
    public Setting getSetting(String n) {
        return settings.stream().filter(s -> s.getName().equalsIgnoreCase(n)).findFirst().orElse(null);
    }
    public float getSlide(float dt) { slide += (targetSlide - slide) * Math.min(1f, dt * 8f); return slide; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public int getKeyBind() { return keyBind; }
    public boolean isEnabled() { return enabled; }
    public boolean isHidden() { return hidden; }
    public List<Setting> getSettings() { return settings; }
    public void setHidden(boolean h) { hidden = h; }
    public void setEnabled(boolean e) { if (e && !enabled) enable(); else if (!e && enabled) disable(); }
}
