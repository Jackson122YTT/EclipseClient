package me.eclipse.module.movement;

import me.eclipse.core.EventHandler;
import me.eclipse.module.Module;
import me.eclipse.module.enums.Category;
import me.eclipse.module.setting.*;
import net.minecraftforge.fml.common.eventhandler.TickEvent;

public class Timer extends Module {
    public Timer() {
        super("Timer", "Game speed", Category.MOVEMENT, 0);
    }
    @Override public void onEnable() { super.onEnable(); }
    @Override public void onDisable() { super.onDisable(); }
    @EventHandler
    public void onTick(TickEvent.PlayerTickEvent e) {
        if(e.phase != TickEvent.Phase.START) return;
        // TODO: Implement Timer
    }
}
