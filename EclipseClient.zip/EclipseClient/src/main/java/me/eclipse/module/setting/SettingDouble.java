package me.eclipse.module.setting;
public class SettingDouble extends Setting {
    private double value, min, max, inc;
    public SettingDouble(String n, double v, double mn, double mx, double i) { super(n); value=v; min=mn; max=mx; inc=i; }
    public double getValue() { return value; }
    public void setValue(double v) { value = v; }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getIncrement() { return inc; }
}
