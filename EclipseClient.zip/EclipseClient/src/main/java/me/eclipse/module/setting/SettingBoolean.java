package me.eclipse.module.setting;
public class SettingBoolean extends Setting {
    private boolean value;
    public SettingBoolean(String n, boolean v) { super(n); value = v; }
    public boolean getValue() { return value; }
    public void setValue(boolean v) { value = v; }
    public double getMin() { return 0; }
    public double getMax() { return 1; }
    public double getIncrement() { return 1; }
}
