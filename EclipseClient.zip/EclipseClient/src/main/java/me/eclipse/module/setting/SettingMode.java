package me.eclipse.module.setting;
public class SettingMode extends Setting {
    private final String[] modes;
    private int idx;
    public SettingMode(String n, String[] m, String def) {
        super(n); modes = m;
        for (int i = 0; i < m.length; i++) if (m[i].equals(def)) { idx = i; return; }
    }
    public String getValue() { return modes[idx]; }
    public void setValue(String v) { for (int i = 0; i < modes.length; i++) if (modes[i].equals(v)) { idx = i; return; } }
    public String[] getModes() { return modes; }
    public double getMin() { return 0; }
    public double getMax() { return modes.length - 1; }
    public double getIncrement() { return 1; }
}
