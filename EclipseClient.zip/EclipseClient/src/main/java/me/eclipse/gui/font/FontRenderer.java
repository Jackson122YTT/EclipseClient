package me.eclipse.gui.font;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

public class FontRenderer {
    private final Map<Character, Glyph> glyphs = new HashMap<>();
    private float height;
    private final ResourceLocation tex;
    
    private static class Glyph { float u,v,w,h,adv,ox,oy; }
    
    public FontRenderer(Font font, boolean aa, boolean fm) {
        int W=1024,H=1024; BufferedImage img=new BufferedImage(W,H,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g=img.createGraphics();
        if(aa){g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);}
        g.setFont(font);g.setColor(Color.WHITE);
        java.awt.FontMetrics metrics=g.getFontMetrics();
        int x=1,y=1,lh=metrics.getHeight()+2;
        for(int i=32;i<256;i++){char c=(char)i;int cw=metrics.charWidth(c);
            if(x+cw+2>W){x=1;y+=lh;}if(y+lh>H)break;
            g.drawString(String.valueOf(c),x,y+metrics.getAscent());
            Glyph gl=new Glyph();gl.u=x/(float)W;gl.v=y/(float)H;gl.w=cw/(float)W;gl.h=lh/(float)H;gl.adv=cw;gl.ox=0;gl.oy=-metrics.getAscent();
            glyphs.put(c,gl);x+=cw+2;}
        g.dispose();
        tex=Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("eclipse_font",new DynamicTexture(img));
        height=(float)metrics.getHeight()*0.65f;
    }
    
    public float drawString(String text,float x,float y,int color,boolean shadow){
        if(text==null||text.isEmpty())return x;
        GlStateManager.enableBlend();GlStateManager.blendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);GlStateManager.disableDepth();
        Minecraft.getMinecraft().getTextureManager().bindTexture(tex);
        float a=(color>>24&255)/255f,r=(color>>16&255)/255f,g=(color>>8&255)/255f,b=(color&255)/255f;
        if(shadow)drawInternal(text,x+1,y+1,0,0,0,a*0.5f);
        float rx=drawInternal(text,x,y,r,g,b,a);
        GlStateManager.enableDepth();GlStateManager.disableBlend();return rx;
    }
    private float drawInternal(String text,float x,float y,float r,float g,float b,float a){
        GlStateManager.color(r,g,b,a);GL11.glBegin(GL11.GL_QUADS);float cx=x;
        for(int i=0;i<text.length();i++){char c=text.charAt(i);Glyph gl=glyphs.get(c);
            if(gl==null){Glyph sp=glyphs.get(' ');if(sp!=null)cx+=sp.adv;continue;}
            float x1=cx+gl.ox,y1=y+gl.oy,x2=x1+gl.w*1024,y2=y1+gl.h*1024;
            GL11.glTexCoord2f(gl.u,gl.v);GL11.glVertex2f(x1,y1);
            GL11.glTexCoord2f(gl.u+gl.w,gl.v);GL11.glVertex2f(x2,y1);
            GL11.glTexCoord2f(gl.u+gl.w,gl.v+gl.h);GL11.glVertex2f(x2,y2);
            GL11.glTexCoord2f(gl.u,gl.v+gl.h);GL11.glVertex2f(x1,y2);
            cx+=gl.adv;}
        GL11.glEnd();return cx;
    }
    public int getStringWidth(String t){if(t==null)return 0;int w=0;for(int i=0;i<t.length();i++){char c=t.charAt(i);Glyph g=glyphs.get(c);w+=g!=null?g.adv:(glyphs.get(' ')!=null?glyphs.get(' ').adv:0);}return w;}
    public float getHeight(){return height;}
}
