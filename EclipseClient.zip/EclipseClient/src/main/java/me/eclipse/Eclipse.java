package me.eclipse;

import me.eclipse.core.*;
import me.eclipse.gui.font.FontRenderer;
import me.eclipse.utils.Logger;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import org.lwjgl.opengl.Display;

@Mod(modid = Eclipse.MOD_ID, name = Eclipse.MOD_NAME, version = Eclipse.VERSION)
public class Eclipse {
    public static final String MOD_ID = "eclipse";
    public static final String MOD_NAME = "Eclipse";
    public static final String VERSION = "2.0.0";
    
    public static Eclipse instance;
    public ModuleManager moduleManager;
    public CommandManager commandManager;
    public ConfigManager configManager;
    public FriendManager friendManager;
    public WaypointManager waypointManager;
    public RotationManager rotationManager;
    public EventBus eventBus;
    public FontRenderer fontRenderer;
    public FontRenderer fontRendererBold;
    public FontRenderer monoFont;
    public static String commandPrefix = ".";
    
    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        instance = this;
        long start = System.currentTimeMillis();
        
        eventBus = new EventBus();
        moduleManager = new ModuleManager();
        commandManager = new CommandManager();
        configManager = new ConfigManager();
        friendManager = new FriendManager();
        waypointManager = new WaypointManager();
        rotationManager = new RotationManager();
        
        try {
            fontRenderer = new FontRenderer(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 18), true, true);
            fontRendererBold = new FontRenderer(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 18), true, true);
            monoFont = new FontRenderer(new java.awt.Font("Consolas", java.awt.Font.PLAIN, 14), true, true);
        } catch (Exception e) {
            Logger.log("Font load failed: " + e.getMessage());
        }
        
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(moduleManager);
        configManager.loadConfigs();
        
        long ms = System.currentTimeMillis() - start;
        Logger.log("Eclipse v" + VERSION + " loaded in " + ms + "ms");
        Logger.log("Modules: " + moduleManager.getModules().size());
        Display.setTitle("Eclipse 2.0 | 1.8.9");
    }
}
