package me.eclipse.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

public class Logger {
    private static final String P = EnumChatFormatting.RED + "[" + EnumChatFormatting.WHITE + "Eclipse" + EnumChatFormatting.RED + "]" + EnumChatFormatting.GRAY + "";
    public static void log(String m) {
        if (Minecraft.getMinecraft().thePlayer != null)
            Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText(P + m));
        System.out.println("[Eclipse] " + m);
    }
}
