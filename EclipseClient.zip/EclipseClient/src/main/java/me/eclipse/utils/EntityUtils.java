package me.eclipse.utils;
import net.minecraft.entity.Entity;import net.minecraft.entity.EntityLivingBase;import net.minecraft.entity.monster.EntityMob;import net.minecraft.entity.passive.EntityAnimal;import net.minecraft.entity.player.EntityPlayer;
public class EntityUtils {
    public static boolean isMob(Entity e) { return e instanceof EntityMob; }
    public static boolean isAnimal(Entity e) { return e instanceof EntityAnimal; }
    public static boolean isPlayer(Entity e) { return e instanceof EntityPlayer; }
}
