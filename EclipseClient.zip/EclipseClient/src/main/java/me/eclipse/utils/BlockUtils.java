package me.eclipse.utils;
import net.minecraft.block.Block;import net.minecraft.client.Minecraft;import net.minecraft.util.BlockPos;
public class BlockUtils {
    private static final Minecraft mc = Minecraft.getMinecraft();
    public static Block getBlock(BlockPos p) { return mc.theWorld.getBlockState(p).getBlock(); }
    public static boolean isFullBlock(BlockPos p) { return getBlock(p).isFullBlock(); }
}
