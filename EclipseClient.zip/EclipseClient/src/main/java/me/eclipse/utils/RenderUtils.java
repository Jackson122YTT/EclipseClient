package me.eclipse.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.BlockPos;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import java.awt.*;

public class RenderUtils {
    private static final Minecraft mc = Minecraft.getMinecraft();
    
    public static void drawRoundedRect(float x, float y, float x2, float y2, float r, int color) {
        GlStateManager.enableBlend(); GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GL14.GL_FUNC_ADD, GL14.GL_FUNC_ADD, GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        float a = (color >> 24 & 255) / 255f, red = (color >> 16 & 255) / 255f, g = (color >> 8 & 255) / 255f, b = (color & 255) / 255f;
        Tessellator t = Tessellator.getInstance(); WorldRenderer w = t.getWorldRenderer();
        w.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        addRect(w, x+r, y, x2-r, y2, red, g, b, a); addRect(w, x, y+r, x2, y2-r, red, g, b, a);
        for (int i = 0; i < 4; i++) addCorner(w, i, x, y, x2, y2, r, red, g, b, a);
        t.draw(); GlStateManager.enableTexture2D(); GlStateManager.disableBlend();
    }
    private static void addRect(WorldRenderer w, float x, float y, float x2, float y2, float r, float g, float b, float a) {
        w.pos(x,y2,0).color(r,g,b,a).endVertex(); w.pos(x2,y2,0).color(r,g,b,a).endVertex();
        w.pos(x2,y,0).color(r,g,b,a).endVertex(); w.pos(x,y,0).color(r,g,b,a).endVertex();
    }
    private static void addCorner(WorldRenderer w, int corner, float x, float y, float x2, float y2, float rad, float r, float g, float b, float a) {
        float cx = corner < 2 ? x2-rad : x+rad, cy = corner % 2 == 0 ? y+rad : y2-rad;
        float start = corner * (float)Math.PI/2;
        for (int i = 0; i < 8; i++) {
            float a1 = start + (i/8f)*(float)Math.PI/2, a2 = start + ((i+1)/8f)*(float)Math.PI/2;
            w.pos(cx,cy,0).color(r,g,b,a).endVertex();
            w.pos(cx+(float)Math.cos(a1)*rad, cy+(float)Math.sin(a1)*rad, 0).color(r,g,b,a).endVertex();
            w.pos(cx+(float)Math.cos(a2)*rad, cy+(float)Math.sin(a2)*rad, 0).color(r,g,b,a).endVertex();
        }
    }
    public static void drawRect(float x, float y, float x2, float y2, int color) {
        GlStateManager.enableBlend(); GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GL14.GL_FUNC_ADD, GL14.GL_FUNC_ADD, GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        float a=(color>>24&255)/255f, r=(color>>16&255)/255f, g=(color>>8&255)/255f, b=(color&255)/255f;
        Tessellator t=Tessellator.getInstance(); WorldRenderer w=t.getWorldRenderer();
        w.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        w.pos(x,y2,0).color(r,g,b,a).endVertex(); w.pos(x2,y2,0).color(r,g,b,a).endVertex();
        w.pos(x2,y,0).color(r,g,b,a).endVertex(); w.pos(x,y,0).color(r,g,b,a).endVertex();
        t.draw(); GlStateManager.enableTexture2D(); GlStateManager.disableBlend();
    }
    public static void drawCircle(float cx, float cy, float r, int color) {
        GlStateManager.enableBlend(); GlStateManager.disableTexture2D();
        float a=(color>>24&255)/255f, red=(color>>16&255)/255f, g=(color>>8&255)/255f, b=(color&255)/255f;
        Tessellator t=Tessellator.getInstance(); WorldRenderer w=t.getWorldRenderer();
        w.begin(GL11.GL_TRIANGLE_FAN, DefaultVertexFormats.POSITION_COLOR);
        w.pos(cx,cy,0).color(red,g,b,a).endVertex();
        for(int i=0;i<=32;i++){float ang=(i/32f)*(float)Math.PI*2;w.pos(cx+(float)Math.cos(ang)*r,cy+(float)Math.sin(ang)*r,0).color(red,g,b,a).endVertex();}
        t.draw(); GlStateManager.enableTexture2D(); GlStateManager.disableBlend();
    }
    public static void drawLine(float x1,float y1,float x2,float y2,float w,int c){
        GlStateManager.enableBlend();GlStateManager.disableTexture2D();GL11.glLineWidth(w);
        float a=(c>>24&255)/255f,r=(c>>16&255)/255f,g=(c>>8&255)/255f,b=(c&255)/255f;
        GL11.glBegin(GL11.GL_LINES);GL11.glColor4f(r,g,b,a);GL11.glVertex2f(x1,y1);GL11.glVertex2f(x2,y2);GL11.glEnd();
        GlStateManager.enableTexture2D();GlStateManager.disableBlend();
    }
    public static void drawBlockOutline(BlockPos pos, int color, float lw) {
        GlStateManager.enableBlend(); GlStateManager.disableDepth(); GlStateManager.disableTexture2D(); GL11.glLineWidth(lw);
        float a=(color>>24&255)/255f,r=(color>>16&255)/255f,g=(color>>8&255)/255f,b=(color&255)/255f;
        double x=pos.getX()-mc.getRenderManager().viewerPosX, y=pos.getY()-mc.getRenderManager().viewerPosY, z=pos.getZ()-mc.getRenderManager().viewerPosZ;
        GL11.glBegin(GL11.GL_LINES);GL11.glColor4f(r,g,b,a);
        GL11.glVertex3d(x,y,z);GL11.glVertex3d(x+1,y,z); GL11.glVertex3d(x+1,y,z);GL11.glVertex3d(x+1,y,z+1);
        GL11.glVertex3d(x+1,y,z+1);GL11.glVertex3d(x,y,z+1); GL11.glVertex3d(x,y,z+1);GL11.glVertex3d(x,y,z);
        GL11.glVertex3d(x,y+1,z);GL11.glVertex3d(x+1,y+1,z); GL11.glVertex3d(x+1,y+1,z);GL11.glVertex3d(x+1,y+1,z+1);
        GL11.glVertex3d(x+1,y+1,z+1);GL11.glVertex3d(x,y+1,z+1); GL11.glVertex3d(x,y+1,z+1);GL11.glVertex3d(x,y+1,z);
        GL11.glVertex3d(x,y,z);GL11.glVertex3d(x,y+1,z); GL11.glVertex3d(x+1,y,z);GL11.glVertex3d(x+1,y+1,z);
        GL11.glVertex3d(x+1,y,z+1);GL11.glVertex3d(x+1,y+1,z+1); GL11.glVertex3d(x,y,z+1);GL11.glVertex3d(x,y+1,z+1);
        GL11.glEnd(); GlStateManager.enableDepth(); GlStateManager.enableTexture2D(); GlStateManager.disableBlend();
    }
    public static void startScissor(float x, float y, float w, float h) {
        ScaledResolution sr = new ScaledResolution(mc); int s = sr.getScaleFactor();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor((int)(x*s),(int)((sr.getScaledHeight()-y-h)*s),(int)(w*s),(int)(h*s));
    }
    public static void endScissor() { GL11.glDisable(GL11.GL_SCISSOR_TEST); }
}
