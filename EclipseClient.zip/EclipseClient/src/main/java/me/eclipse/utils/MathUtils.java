package me.eclipse.utils;
import net.minecraft.client.Minecraft;
public class MathUtils {
    private static final Minecraft mc = Minecraft.getMinecraft();
    public static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
    public static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
}
