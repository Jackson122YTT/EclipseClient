package me.eclipse.utils;
public class AnimationUtils {
    public static float easeOutCubic(float t) { return 1f - (float)Math.pow(1-t, 3); }
    public static float easeInCubic(float t) { return t*t*t; }
    public static float easeOutBack(float t) { float c=1.70158f; return 1f+(c+1f)*(float)Math.pow(t-1f,3)+c*(float)Math.pow(t-1f,2); }
    public static float easeOutBounce(float t) {
        float n=7.5625f,d=2.75f;
        if(t<1f/d)return n*t*t;else if(t<2f/d){t-=1.5f/d;return n*t*t+0.75f;}
        else if(t<2.5f/d){t-=2.25f/d;return n*t*t+0.9375f;}else{t-=2.625f/d;return n*t*t+0.984375f;}
    }
    public static float lerp(float from, float to, float speed) { return from + (to-from) * Math.min(1f, speed); }
}
