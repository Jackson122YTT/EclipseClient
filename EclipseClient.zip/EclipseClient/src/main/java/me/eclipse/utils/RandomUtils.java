package me.eclipse.utils;
import java.util.Random;
public class RandomUtils {
    private static final Random r = new Random();
    public static int nextInt(int min, int max) { return min + r.nextInt(max - min + 1); }
    public static float nextFloat(float min, float max) { return min + r.nextFloat() * (max - min); }
    public static double nextDouble(double min, double max) { return min + r.nextDouble() * (max - min); }
    public static double nextGaussian(double sd) { return r.nextGaussian() * sd; }
    public static boolean chance(double pct) { return r.nextDouble() * 100 < pct; }
}
