package me.eclipse.utils;
import net.minecraft.client.Minecraft;
public class BlurUtils {
    public static void renderBlur(float strength) {
        // Simplified blur overlay
        RenderUtils.drawRect(0, 0, Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight, 0x80000000);
    }
}
