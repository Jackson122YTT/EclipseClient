package me.eclipse.network;

import me.eclipse.core.Cancellable;
import net.minecraft.network.Packet;

public class PacketEvent {
    public static class Send implements Cancellable {
        private Packet<?> packet; private boolean cancelled;
        public Send(Packet<?> p) { packet = p; }
        public Packet<?> getPacket() { return packet; }
        public boolean isCancelled() { return cancelled; }
        public void setCancelled(boolean c) { cancelled = c; }
    }
    public static class Receive implements Cancellable {
        private Packet<?> packet; private boolean cancelled;
        public Receive(Packet<?> p) { packet = p; }
        public Packet<?> getPacket() { return packet; }
        public boolean isCancelled() { return cancelled; }
        public void setCancelled(boolean c) { cancelled = c; }
    }
}
