package me.eclipse.mixin;

import me.eclipse.Eclipse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(net.minecraft.network.NetworkManager.class)
public class MixinNetworkManager {
    @Inject(method = "func_XXXXX", at = @At("HEAD"), cancellable = true)
    private void hook(CallbackInfo ci) {
        // TODO: Implement MixinNetworkManager
    }
}
