package me.eclipse.mixin;

import me.eclipse.Eclipse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(net.minecraft.client.renderer.entity.RendererLivingEntity.class)
public class MixinRendererLivingEntity {
    @Inject(method = "func_XXXXX", at = @At("HEAD"), cancellable = true)
    private void hook(CallbackInfo ci) {
        // TODO: Implement MixinRendererLivingEntity
    }
}
