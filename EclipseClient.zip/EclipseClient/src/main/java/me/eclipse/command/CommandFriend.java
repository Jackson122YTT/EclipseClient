package me.eclipse.command;
import me.eclipse.Eclipse;
public class CommandFriend extends Command {
    public CommandFriend() { super("friend", "Manage friends"); }
    public void execute(String[] a) {
        if(a.length<2){chat("Usage: .friend <add/remove> <name>");return;}
        if(a[0].equalsIgnoreCase("add")){Eclipse.instance.friendManager.addFriend(a[1]);chat("Added: "+a[1]);}
        else if(a[0].equalsIgnoreCase("remove")){Eclipse.instance.friendManager.removeFriend(a[1]);chat("Removed: "+a[1]);}
    }
}
