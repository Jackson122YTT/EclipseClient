package me.eclipse.command;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

public abstract class Command {
    protected final String name, description;
    protected final String[] aliases;
    protected final Minecraft mc = Minecraft.getMinecraft();
    
    public Command(String n, String d, String... a) { name = n; description = d; aliases = a; }
    public abstract void execute(String[] args);
    public boolean matches(String i) {
        if(i.equalsIgnoreCase(name)) return true;
        for(String a : aliases) if(i.equalsIgnoreCase(a)) return true;
        return false;
    }
    public String getName() { return name; }
    protected void chat(String m) { if(mc.thePlayer!=null) mc.thePlayer.addChatMessage(new ChatComponentText("\u00a77[\u00a7cEclipse\u00a77] \u00a7f"+m)); }
    protected void error(String m) { if(mc.thePlayer!=null) mc.thePlayer.addChatMessage(new ChatComponentText("\u00a77[\u00a7cEclipse\u00a77] \u00a7c"+m)); }
}
