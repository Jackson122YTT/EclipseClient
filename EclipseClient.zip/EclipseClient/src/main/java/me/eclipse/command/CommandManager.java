package me.eclipse.command;

import me.eclipse.Eclipse;
import me.eclipse.utils.Logger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommandManager {
    private final List<Command> cmds = new ArrayList<>();
    public CommandManager() {
        cmds.add(new CommandToggle()); cmds.add(new CommandBind()); cmds.add(new CommandFriend());
        cmds.add(new CommandConfig()); cmds.add(new CommandHelp()); cmds.add(new CommandWatchdog());
    }
    public void handleCommand(String msg) {
        if(!msg.startsWith(Eclipse.commandPrefix)) return;
        String[] p = msg.substring(Eclipse.commandPrefix.length()).split(" ");
        String cn = p[0]; String[] args = Arrays.copyOfRange(p, 1, p.length);
        for(Command c : cmds) { if(c.matches(cn)) { try{c.execute(args);}catch(Exception e){Logger.log("Err:"+e);} return; } }
        Logger.log("Unknown: " + cn);
    }
    public List<Command> getCommands() { return cmds; }
}
