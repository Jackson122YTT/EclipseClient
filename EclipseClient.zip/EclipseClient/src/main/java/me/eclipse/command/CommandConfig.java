package me.eclipse.command;
public class CommandConfig extends Command {
    public CommandConfig() { super("config", "Manage configs"); }
    public void execute(String[] a) { chat("Usage: .config <save/load> <name>"); }
}
