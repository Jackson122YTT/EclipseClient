package me.eclipse.command;
public class CommandBind extends Command {
    public CommandBind() { super("bind", "Bind module"); }
    public void execute(String[] a) { chat("Usage: .bind <module> <key>"); }
}
