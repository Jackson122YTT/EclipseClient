package me.eclipse.command;
import me.eclipse.Eclipse;
import me.eclipse.module.watchdog.WDProfile;
public class CommandWatchdog extends Command {
    public CommandWatchdog() { super("watchdog", "WD bypass", "wd"); }
    public void execute(String[] a) {
        if(a.length<1){chat("\u00a7c.watchdog <profile|status>");return;}
        if(a[0].equals("profile")&&a.length>1){
            WDProfile p=Eclipse.instance.moduleManager.getModule(WDProfile.class);
            if(p!=null){p.getSetting("Profile").setValue(a[1]);chat("Profile: "+a[1]);}
        }else if(a[0].equals("status")){chat("WD modules loaded");}
    }
}
