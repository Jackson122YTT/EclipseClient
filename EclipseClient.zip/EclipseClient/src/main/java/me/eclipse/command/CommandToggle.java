package me.eclipse.command;
import me.eclipse.Eclipse;
import me.eclipse.module.Module;
public class CommandToggle extends Command {
    public CommandToggle() { super("toggle", "Toggle module", "t"); }
    public void execute(String[] a) {
        if(a.length<1){error("Usage: .toggle <module>");return;}
        Module m = Eclipse.instance.moduleManager.getModule(a[0]);
        if(m==null){error("Not found: "+a[0]);return;}
        m.toggle(); chat(m.getName()+" "+(m.isEnabled()?"enabled":"disabled"));
    }
}
