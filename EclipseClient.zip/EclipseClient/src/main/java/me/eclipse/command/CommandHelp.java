package me.eclipse.command;
import me.eclipse.Eclipse;
public class CommandHelp extends Command {
    public CommandHelp() { super("help", "Show commands"); }
    public void execute(String[] a) {
        chat("\u00a7cCommands:");
        for(Command c : Eclipse.instance.commandManager.getCommands()) chat("  \u00a77."+c.getName()+" - "+c.description);
    }
}
