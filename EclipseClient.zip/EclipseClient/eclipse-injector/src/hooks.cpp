#include <Windows.h>
#include <iostream>
#include <unordered_map>
namespace Eclipse {
    static std::unordered_map<std::string, void*> g_hooks;
    class VMTHook {
        uintptr_t** vt; uintptr_t* orig; uintptr_t* newvt; int sz;
    public:
        VMTHook(void* obj) {
            vt = (uintptr_t**)obj; orig = *vt; sz=0;
            while(!IsBadCodePtr((FARPROC)orig[sz]) && sz<1000) sz++;
            newvt = new uintptr_t[sz]; memcpy(newvt,orig,sz*sizeof(uintptr_t)); *vt=newvt;
        }
        ~VMTHook() { if(vt&&orig)*vt=orig; delete[]newvt; }
        void Hook(int i, void* d) { if(i>=0&&i<sz) newvt[i]=(uintptr_t)d; }
        void* GetOrig(int i) { return (void*)orig[i]; }
    };
}
