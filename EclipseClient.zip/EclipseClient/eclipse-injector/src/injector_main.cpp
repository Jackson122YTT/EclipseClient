#include <Windows.h>
#include <iostream>
#include "injector.h"
int main() {
    SetConsoleTitleW(L"Eclipse Injector 2.0");
    std::cout << "\n  Eclipse Injector v2.0 | 1.8.9\n\n  Searching for Minecraft...\n";
    DWORD pid = Eclipse::Injector::FindProcess(L"javaw.exe");
    if (!pid) {
        HWND w = FindWindowW(L"LWJGL",0);
        if (!w) w = FindWindowW(0,L"Minecraft 1.8.9");
        if (w) GetWindowThreadProcessId(w,&pid);
    }
    if (!pid) { std::cout << "  [!] Minecraft not found!\n\n"; std::cin.get(); return 1; }
    std::cout << "  [+] Found PID: " << pid << "\n";
    wchar_t exepath[MAX_PATH]; GetModuleFileNameW(0,exepath,MAX_PATH);
    std::wstring dll = exepath;
    size_t ls = dll.find_last_of(L"\\");
    if (ls!=std::wstring::npos) dll = dll.substr(0,ls) + L"\\Eclipse.dll";
    else dll = L"Eclipse.dll";
    if (Eclipse::Injector::IsInjected(pid,L"Eclipse.dll")) { std::cout << "  [!] Already injected!\n\n"; std::cin.get(); return 0; }
    std::cout << "  Injecting...\n";
    bool ok = Eclipse::Injector::InjectDLL(pid,dll);
    if (ok) { std::cout << "  [+] Injected! GUI: RSHIFT\n"; }
    else { std::cout << "  [!] Failed!\n"; }
    std::cout << "\n  Press any key..."; std::cin.get();
    return ok ? 0 : 1;
}
