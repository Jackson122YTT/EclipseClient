#include <Windows.h>
BOOL APIENTRY DllMain(HMODULE h, DWORD r, LPVOID) {
    if (r==DLL_PROCESS_ATTACH) DisableThreadLibraryCalls(h);
    return TRUE;
}
