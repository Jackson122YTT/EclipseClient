#pragma once
#include <Windows.h>
#include <TlHelp32.h>
#include <string>
namespace Eclipse {
    class Injector {
    public:
        static bool InjectDLL(DWORD pid, const std::wstring& dll);
        static bool InjectDLL(const std::wstring& proc, const std::wstring& dll);
        static DWORD FindProcess(const std::wstring& name);
        static bool IsInjected(DWORD pid, const std::wstring& dll);
    private:
        static bool LoadLibraryInject(DWORD pid, const std::wstring& dll);
    };
}
