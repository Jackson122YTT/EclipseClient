#include "injector.h"
#include <iostream>
namespace Eclipse {
    bool Injector::LoadLibraryInject(DWORD pid, const std::wstring& dll) {
        HANDLE hp = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
        if (!hp) return false;
        size_t sz = (dll.length()+1)*sizeof(wchar_t);
        uintptr_t pa = (uintptr_t)VirtualAllocEx(hp,0,sz,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
        if (!pa) { CloseHandle(hp); return false; }
        WriteProcessMemory(hp,(void*)pa,dll.c_str(),sz,nullptr);
        HMODULE k32 = GetModuleHandleW(L"kernel32.dll");
        uintptr_t ll = (uintptr_t)GetProcAddress(k32,"LoadLibraryW");
        HANDLE ht = CreateRemoteThread(hp,0,0,(LPTHREAD_START_ROUTINE)ll,(void*)pa,0,0);
        if (!ht) { VirtualFreeEx(hp,(void*)pa,0,MEM_RELEASE); CloseHandle(hp); return false; }
        WaitForSingleObject(ht,INFINITE);
        VirtualFreeEx(hp,(void*)pa,0,MEM_RELEASE); CloseHandle(ht); CloseHandle(hp);
        return true;
    }
    bool Injector::InjectDLL(DWORD pid, const std::wstring& dll) { return LoadLibraryInject(pid,dll); }
    bool Injector::InjectDLL(const std::wstring& proc, const std::wstring& dll) {
        DWORD pid = FindProcess(proc); return pid ? InjectDLL(pid,dll) : false;
    }
    DWORD Injector::FindProcess(const std::wstring& name) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
        if (snap==INVALID_HANDLE_VALUE) return 0;
        PROCESSENTRY32W e; e.dwSize=sizeof(e); DWORD r=0;
        if (Process32FirstW(snap,&e)) { do { if(_wcsicmp(e.szExeFile,name.c_str())==0){r=e.th32ProcessID;break;} } while(Process32NextW(snap,&e)); }
        CloseHandle(snap); return r;
    }
    bool Injector::IsInjected(DWORD pid, const std::wstring& dll) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,pid);
        if (snap==INVALID_HANDLE_VALUE) return false;
        MODULEENTRY32W e; e.dwSize=sizeof(e); bool f=false;
        if (Module32FirstW(snap,&e)) { do { if(_wcsicmp(e.szModule,dll.c_str())==0){f=true;break;} } while(Module32NextW(snap,&e)); }
        CloseHandle(snap); return f;
    }
}
